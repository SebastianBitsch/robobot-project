 /***************************************************************************
 * definition file for the regbot.
 * The main function is the controlTick, that is called 
 * at a constant time interval (of probably 1.25 ms, see the intervalT variable)
 * 
 * The main control functions are in control.cpp file
 * 
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "control.h"
#include "data_logger.h"
#include "motor_controller.h"
#include "serial_com.h"
#include "robot.h"
#include "mission.h"

// mission state 0 is waiting for start button
// mission state 999 is end - finished
int16_t missionState;
int16_t missionStateLast;
float mission_turn_ref = 0.0;    /// reference angle for heading control
float mission_vel_ref = 0.0;     /// base velocity
bool mission_turn_do = false;    /// is in a turn - specified by turn radius
float mission_turn_radius = 0.0; /// turn radius when dooing a turn
//float balance_tilt_offset = 0.0; // -30*M_PI/180.0; /// balance ref (30 degrees)
float regul_bal_uvel = 0.0; /// output of balance regulator to be added to wheel velocity control
/**
  * Parameters for balance control */
int regul_bal_use = 0;      /// use balance control (and not in a turn)
bool regul_balvel_use = 1;
float regul_bal_kp = 5.0;
float regul_bal_ti = 0.0;
float regul_bal_td = 0.0;
float regul_bal_alpha = 0.0;
float regul_bal_i_limit = 0.0; // integrator limit, 0=no limit
float regul_bal_u_limit = 0.0; // output limit, 0 = no limit
bool  regul_bal_LeadFwd = false;
float posoff,tilt0;
/**
 * Parameters for velocity control when using balance control (controls tilt reference) */
float regul_balvel_kp = 5.0;
float regul_balvel_ti = 0.0;
float regul_balvel_td = 0.0;
float regul_balvel_alpha = 0.0;
float regul_balvel_zeta = 0.0;
float regul_balvel_i_limit = 0.0; // integrator limit, 0 = no limit
float regul_balvel_u_limit = 0.0; // output limit, 0 = no lomit
bool   regul_balVel_LeadFwd = false;
/** step parameters for balance velocity */
float regul_balvel_step_time = 0.3;
float regul_balvel_step_from = 0.0;
float regul_balvel_step_to = 0.0;
/** turn regulator */
int regul_turn_use = 0;  // use heading control (when not in a turn)
float regul_turn_kp = 5.0;
float regul_turn_ti = 0.0;
float regul_turn_td = 0.0;
float regul_turn_alpha = 0.0;
float regul_turn_i_limit = 0.0; // integrator limit, 0=no limit
bool regul_turn_LeadFwd = false;
/** test step for turn */
float regul_turn_step_time_on = 0.2;
float regul_turn_step_time_off = 0.4; 
float regul_turn_step_val = 0.5;
float regul_turn_step_vel = 0.5;
/** result of regulator turn controll and acceleration limit
 *  used by the velocity controller */
float regul_turn_vel_reduc[2] = {0.0, 0.0};
/** acceleration limit on mission velocity, when 
 * useing balance controller */
float regul_balvel_reduc = 0.0;
/**
 * velocity PID regulator parameters */
int regul_vel_use = 0;          // use velocity control
float regul_vel_kp = 5.0;
float regul_vel_ti = 0.0;
float regul_vel_td = 0.0;
float regul_vel_alpha = 0.0;
float regul_vel_i_limit = 0.0; // integrator limit, 0=no limit
float regul_acc_limit = 100.0; // no acc limit (m/s²)
bool regul_vel_LeadFwd = false;
/** step parameters */
float regul_vel_step_time = 0.3;
float regul_vel_step_from = 1.5;
float regul_vel_step_to = 2.5;
/** actual velocity control reference - acceleration limited */
float regul_vel_ref[2] = {0.0, 0.0}; // reference for velocity controller
float regul_vel_tot_ref[2] = {0, 0}; // added also balance without acceleration limit
//
/**
 * velocity controller P-Lead */
float regVelELeft[2];  // input lead forward
float regVelULeft[1];  // output value of controller
float regVelMLeft[2];  // measurement input
float regVelUDLeft[2]; // output Lead
//
float regVelERight[2];  // input lead forward
float regVelURight[1];  // output value of controller
float regVelMRight[2];  // measurement input
float regVelUDRight[2]; // output Lead
// parametrs (common) for wheel velocity
float regVelParU[2];    // lead params output side
float regVelParE[2];    // lead param input side
// velocity integral part uses regVelE or regVelUD as input
float regVelUILeft[2];  // output of I-term
float regVelUIRight[2]; // output of I-term
float regVelParUI[2];
float regVelParEI[2];

// regulator turn - P-Lead
float regTurnE[2];  // error input
float regTurnU[1];  // output value of controller
float regTurnM[2];  // measurement input
float regTurnUD[2]; // lead output
float regTurnParU[2]; // param for lead (y)
float regTurnParE[2]; // param for lead (x)
// turn integral part
float regTurnUI[2]; // output of integral part
float regTurnParUI[2]; // param for I-term (y)
float regTurnParEI[2]; // param for I-term (X)

/// balance - Z implementation and last values
float regBalE[2];  // error input
float regBalU[1];  // output value of controller
float regBalM[2];  // measurement input
float regBalUD[2]; // output of lead
float regBalParU[2]; // param for Lead (y)
float regBalParE[2]; // param for Lead (x)
// integral part
float regBalUI[2];   // output of I-term
float regBalParUI[2];// param for I-term (y)
float regBalParEI[2];// param for I-term (x)
float intgbal;

/// balance velocity - Z implementation and last values
/// Lead may have complex poles
float regBalVelE[3];  // error input 
float regBalVelU[1];  // output value of controller
float regBalVelM[3];  // measurement input
float regBalVelUD[3]; // output of Lead
float regBalVelParU[3]; // param for Lead (y)
float regBalVelParE[3]; // param for Lead (x)
// integral part
float regBalVelUI[2]; // output of I-term
float regBalVelParUI[2]; // param for I-term (y)
float regBalVelParEI[2]; // param for I-term (x)
//
float balTiltRef; // reference value for tilt controller (for data logger)

int mission = 0;
const int missionMax = 4;
const char * missionName[missionMax] = 
                            {"Velocity_step",
                              "Turn_step",
                              "Balance_test",
                              "User_mission"};
UMission * misLine = NULL;  // current mission line    "User_mission"};
UMission * misLineLast = NULL;  // current mission line    "User_mission"};

int16_t misLineNum = 0;         // current mission line number
int misLineNumLast = 0;
int misStartTime;           // start time for this line
float misLastAng;          // start heading for this line
float misAngSum;            // turned angle for this line
float misStartDist;         // start distance for this line
int misLast = -1;
int misStateLast = -1;
  
//////////////////////////////////////  
//////////////////////////////////////  
//////////////////////////////////////  

void sendStatusMission()
{
  const int MSL = 120;
  char s[MSL];
  if (mission != misLast or missionState != misStateLast)
  {
    snprintf(s, MSL, "mis %d %d %d '%s' %d\r\n",
            mission, missionState, misLineNum, 
            missionName[mission],
            sendStatusWhileRunning
          );
    usb_send_str(s);
    misLast = mission;
    misStateLast = missionState;
  }
  if (misLine != NULL and misLine != misLineLast)
  {
    char * p1;
    int n;
    snprintf(s, MSL, "#mis %d %d %d '",
             mission, missionState, misLineNum);
    n = strlen(s);
    p1 = &s[n];
    n += misLine->toString(p1, MSL - n - 4, false);
    p1 = &s[n];
    strncpy(p1, "'\r\n", 4);
    usb_send_str(s);
    misLineLast = misLine;
  }
  // debug
//   if (missionState > 0) 
//   {
//     snprintf(s, MSL, "#time %.3f mission %d, state %d.%d, logger line %d/%d\r\n", 
//              time, mission, missionState, misLineNum, logRowCnt, logRowsCntMax);
//     usb_send_str(s);
//   }
  // debug end
}

void sendStatusControl()
{
  const int MSL = 180;
  char s[MSL];
  snprintf(s, MSL, "rgt %d %f %f %f %f %f %f %f %f %f %d\n", // use kp ti td al limit step_on step_off step_val step_vel
           regul_turn_use, regul_turn_kp, regul_turn_ti, regul_turn_td, regul_turn_alpha, regul_turn_i_limit,
           regul_turn_step_time_on, regul_turn_step_time_off, regul_turn_step_val, regul_turn_step_vel, regul_turn_LeadFwd
  );
  usb_send_str(s);
  snprintf(s, MSL, "rgv %d %f %f %f %f %f %f %f %f %f %d %d %f\n",
           regul_vel_use, regul_vel_kp, regul_vel_ti, regul_vel_td, regul_vel_alpha, regul_vel_i_limit,
           regul_vel_step_time, regul_vel_step_from, regul_vel_step_to, 
           regul_acc_limit, regul_vel_est, regul_vel_LeadFwd, max_motor_voltage
  );
  usb_send_str(s);
  // speed and turn Z-expression
  snprintf(s, MSL,  "rgvz %f %f %f\n"
                    "rgvzi %f %f %f\r\n" // denom[1], numer[0] numer[1]
                    "rgtz %f %f %f\n"
                    "rgtzi %f %f %f\r\n", // denom[1], numer[0] numer[1]
                    regVelParU[1], regVelParE[0], regVelParE[1],
                    regVelParUI[1], regVelParEI[0], regVelParEI[1],
                    regTurnParU[1], regTurnParE[0], regTurnParE[1],
                    regTurnParUI[1], regTurnParEI[0], regTurnParEI[1]
  );
  usb_send_str(s);
  // balance control - and balance velocity step
  snprintf(s, MSL, "rgb %d %f %f %f %f %f %f %f %f %d %d %f\n",
           regul_bal_use, regul_bal_kp, regul_bal_ti, regul_bal_td, regul_bal_alpha, regul_bal_i_limit,
           regul_balvel_step_time, regul_balvel_step_from, regul_balvel_step_to, regul_balvel_use, regul_bal_LeadFwd, regul_bal_u_limit
  );
  usb_send_str(s);
  // balance mission velocity
  snprintf(s, MSL, "rgmv %f %f %f %f %f %f %d %f\n",
           regul_balvel_kp, regul_balvel_ti, regul_balvel_td, regul_balvel_alpha, regul_balvel_zeta, 
           regul_balvel_i_limit, regul_balVel_LeadFwd, regul_balvel_u_limit
  );
  usb_send_str(s);
  // balance and speed Z-expression
  snprintf(s, MSL,  "rgbz %f %f %f\n"
          "rgbzi %f %f %f\r\n" // denom[1], numer[0] numer[1]
          "rgmvz %f %f %f %f %f\n"
          "rgmvzi %f %f %f\r\n", // denom[1], numer[0] numer[1]
          regBalParU[1], regBalParE[0], regBalParE[1],
          regBalParUI[1], regBalParEI[0], regBalParEI[1],
          regBalVelParU[1], regBalVelParU[2], regBalVelParE[0], regBalVelParE[1], regBalVelParE[2],
          regBalVelParUI[1], regBalVelParEI[0], regBalVelParEI[1]
  );
  usb_send_str(s);
}

/**
 * Step on velocity, as specified by GUI
 * parameter estimate mission (should use fast logging) */
void motor_vel_gui_step()
{
  const int MSL = 60;
  char s[MSL];
  switch (missionState)
  {
    case 0: // wait for start button
      if (button or missionStart)
      { // goto next state
        time = 0.0;
        // ensure main log options are on
        logRowFlags[LOG_MOTV] = true;    // orderd anchor voltage before PWM
        logRowFlags[LOG_WHEELVEL] = true;  // wheel velocity in rad/s
        mission_vel_ref = 0.0;
        mission_turn_do = false;
        regul_vel_ref[0] = 0.0;
        regul_vel_ref[1] = 0.0;
        missionState = 1;
      }
      break;
    case 1:
      if (time > 1.0) // wait for finger away from button
      { // go to next state
        time = 0.0;
        clearPose();
        startLogging(logInterval); 
        mission_vel_ref = regul_vel_step_from;
        // debug
        snprintf(s, MSL, "# mission vel ref from %.2f rad/s\n", mission_vel_ref);
        usb_write(s);
        // debug end
        motorSetEnable(true, true);
        missionState = 2;
      }
      break;
    case 2:
      if (time > regul_vel_step_time or not loggerLogging())
      { // go to next state
        missionState = 4;
        mission_vel_ref = regul_vel_step_to;
        // debug
        snprintf(s, MSL, "# mission vel ref to   %.2f rad/s at %.3f\n", mission_vel_ref, time);
        usb_write(s);
        // debug end
      }
      break;
    case 4:
      // continue until log buffer is full
      if (not loggerLogging())
      { // finished logging
        // finish
        mission_vel_ref = 0.0;
        missionState = 999;
        // debug
        snprintf(s, MSL, "# mission vel ref to   %.2f rad/s at %.3f\n", mission_vel_ref, time);
        usb_write(s);
        // debug end
      }
      break;
    default:
      // go back to - try again.
      motorAnkerVoltage[0] = 0;
      motorAnkerVoltage[1] = 0;
      mission_turn_do = false;
      mission_vel_ref = 0;
      motorSetEnable(false, false);
      stopLogging();
      if (not button)
        missionState = 0;
      break;
  }
  if (hbTimerCnt % 100 == 0)
  {
    sendStatusMission();
  }
}

/**
 * Step on turn, as specified by GUI
 * parameter estimate mission (should use fast logging) */
void mission_gui_turn_step()
{
  switch (missionState)
  {
    case 0: // wait for start button
      if (button or missionStart)
      { // goto next state
        time = 0.0;
        clearPose(); 
        // ensure main log options are on
        logRowFlags[LOG_TURNRATE] = true;  // robot turnrate
        logRowFlags[LOG_MOTV_REF] = true;  // u(t) - ref for motor
        logRowFlags[LOG_POSE] = true;      // robot pose (heading)
        missionState = 1; 
        mission_turn_ref = 0.0;
        mission_turn_do = false;
        mission_vel_ref = 0.0;
      }
      break;
    case 1:
      if (time > 1.0) // wait for finger away from button
      { // go to next state
        time = 0.0;
        clearPose();
        startLogging(logInterval); 
        mission_vel_ref = regul_turn_step_vel;
        mission_turn_ref = 0.0;
        motorSetEnable(true, true);
        missionState = 2;
      }
      break;
    case 2: // straight
      if (time > regul_turn_step_time_on)
      { // go to turn
        missionState = 4;
        mission_turn_ref = regul_turn_step_val;
      }
      break;
    case 4: // turn
      if (time > regul_turn_step_time_off)
      { // go to next state - no more turn
        missionState = 6;
        mission_turn_ref = 0.0;
      }
      break;
    case 6: // straight
      // continue until log buffer is full
      if (not loggerLogging())
      { // finished logging so stop
        mission_turn_ref = 0.0;
        mission_vel_ref = 0.0;
        missionState = 998;
      }
      break;
    default: // stop
      motorAnkerVoltage[0] = 0;
      motorAnkerVoltage[1] = 0;
      mission_vel_ref = 0;
      motorSetEnable(false, false);
      stopLogging();
      if (not button)
        missionState = 0;
      break;
  }
}

/**
 * run mission from user lines */
void user_mission()
{
//   const int MSL = 180;
//   char s[MSL];
  switch (missionState)
  {
    case 0: // wait for start button
      if (button or missionStart)
      { // goto next state
        time = 0.0;
        missionState = 1;
        mission_vel_ref = 0;
        mission_turn_ref = 0;
        misLineNum = 0;
      }
      break;
    case 1: // wait to allow release of button
      if (time > 1.0)
      { // init next state
        if (mLinesCnt > 0)
        {
          missionState = 2;
        }
        else
        {  // no user defined lines
          missionState = 999;
          break;
        }
        // start real mission
        misLine = &mLines[misLineNum];
        time = 0.0;
        clearPose();
        misLastAng = pose[2];
        misStartDist = distance;
        misStartTime = hbTimerCnt;
        misAngSum = 0;
        mission_turn_ref = pose[2];
        if (misLine->logUse and misLine->log > 0)
          startLogging(misLine->log);
        else
          stopLogging();
        if (misLine->balUse)
          regul_bal_use = misLine->bal;
        else
          regul_bal_use = false;
        if (misLine->velUse)
          // change velocity
          mission_vel_ref = misLine->vel/odoWheelRadius[0];
        else
          mission_vel_ref = 0.2/odoWheelRadius[0];
        if (misLine->trUse)
        { // turn radius in meters positive i left
          mission_turn_radius = misLine->tr;
          mission_turn_do = true;
        }
        else
        { // no turn this time - keep current turn ref
          mission_turn_do = false;
          if (regul_turn_use)
            mission_turn_ref = pose[2];
          else
            mission_turn_ref = 0.0;
        }
        if (misLine->accUse)
          regul_acc_limit = misLine->acc;
        // debug
//         snprintf(s, MSL, "# mission line %d: turn_ref=%g, h=%g \n", misLineNum, mission_turn_ref, pose[2]);
//         usb_write(s);
        // debug end        
        // set start parameters
        motorSetEnable(true, true);
      }
      break;
    case 2:
      // run user mission lines
      {
        bool finished = false;
        // integrate heading change to
        // allow turn of more than 360 degrees
        if (misLine->turnUse or misLine->distUse or misLine->timeUse)
        { // there is a continue condition
          float ta = pose[2] - misLastAng;
          if (misLine->turnUse)
          { // avoid angle folding
            if (ta > M_PI)
              ta -= 2* M_PI;
            else if (ta < -M_PI)
              ta += 2 * M_PI; 
            misAngSum += ta;
            misLastAng = pose[2];
            finished = misAngSum * 180/M_PI > fabs(misLine->turn);
          }
          if (not finished and misLine->distUse)
          { 
            finished = misLine->dist < fabsf(distance - misStartDist);
          }
          if (not finished and misLine->timeUse)
          {
            finished = misLine->time < float(hbTimerCnt - misStartTime)/1000.0;
          }
          if (misLine->turnUse)
          {
            if (not finished)
            {
              finished = fabsf(misAngSum) * 180/M_PI > fabsf(misLine->turn);
              if (finished)
              {
                // debug
//                 snprintf(s, MSL, "# turn end, ref=%g, turned=%g, h=%g\n", mission_turn_ref, misLine->turn, pose[2]);
//                 int n = strlen(s);
//                 misLine->toString(&s[n], MSL - n, true);
//                 usb_write(s);
                // debug end
                mission_turn_ref += misLine->turn * M_PI / 180.0;
                while (mission_turn_ref > M_PI)
                  mission_turn_ref -= 2 * M_PI;
                while (mission_turn_ref < -M_PI)
                  mission_turn_ref += 2 * M_PI;
              }
            }
            else
              mission_turn_ref = pose[2];
          }
//           if (finished or (hbTimerCnt % 20 == 0))
//           {
//             snprintf(s, MSL, "# line %d %d odo %.3f %.3f %.4f dist %.3f startdist %.3f\n", 
//                     misLineNum, finished, pose[0], pose[1], pose[2], distance, misStartDist);
//             usb_write(s);
//           }
        }
        else
        {
          finished = true;
          usb_write("# mission line - no condition\n");
        }
        if (finished)
        { // initialize new mission line
          // debug
//           snprintf(s, MSL, "# finished line %d: turn_ref=%g, h=%g\n", misLineNum, mission_turn_ref, pose[2]);
//           usb_write(s);
          // debug end
          misLineNum++;
          if (misLineNum < mLinesCnt)
          { // prepare next line
            misLine = &mLines[misLineNum];
            misAngSum = 0; 
            misLastAng = pose[2];
            misStartDist = distance;
            misStartTime = hbTimerCnt;
            if (misLine->logUse)
            { // logging may have changed
              if (misLine->log > 0)
                startLogging(misLine->log);
              else
                stopLogging();
            }
            if (misLine->balUse)
              regul_bal_use = misLine->bal;
            if (misLine->velUse)
              // change velocity
              mission_vel_ref = misLine->vel/odoWheelRadius[0];
            if (misLine->trUse)
            { // turn radius in meters positive i left
              mission_turn_radius = misLine->tr;
              mission_turn_do = true;
            }
            else
            { // no turn this time - keep current turn ref
              mission_turn_do = false;
//               if (regul_turn_use)
//                 mission_turn_ref = pose[2];
//               else
//                 mission_turn_ref = 0.0;
            }
            if (misLine->accUse)
              regul_acc_limit = misLine->acc;
            // debug
//             snprintf(s, MSL, "# start line %d: turn_ref=%g, h=%g\n", misLineNum, mission_turn_ref, pose[2]);
//             int n = strlen(s);
//             misLine->toString(&s[n], MSL - n, true);
//             usb_write(s);
            // debug end
          }
          else
          {
            missionState = 999;
            usb_write("# mission line - no more lines\n");
          }
        }
      }
      break;
    default:
      // no more state, stop motors
      motorAnkerVoltage[0] = 0;
      motorAnkerVoltage[1] = 0;
      mission_turn_do = false;
      mission_vel_ref = 0;
      motorSetEnable(false, false);
      stopLogging();
      misLine = NULL;
      misLineNum = 0;
      // go back to - try again.
      // if button is released
      if (not button)
        missionState = 0;
      break;
  }
}


/**
 * parameter estimate mission with slow logging */
void balance_test()
{
//   if (missionState > 0)
//     // drive with constant speed
//     addMotorVoltage(-2, -2);
  // then turn left and right
  switch (missionState)
  {
    case 0: // wait for start button
      if (button or missionStart)
      { // goto next state
        time = 0.0;
        missionState = 1; 
      }
      break;
    case 1: // wait to allow release of button
      if (time > 1.0)
      { // goto next state
        time = 0.0;
        clearPose();
        mission_vel_ref = regul_balvel_step_from;
        startLogging(logInterval); 
        missionState = 2; 
        // go straight
        addMotorTurnrate(0);
        // and start the engines
        motorSetEnable(true, true);
      }
      break;
    case 2:
      // continue until log buffer is full
      if (not loggerLogging() or time > regul_balvel_step_time)
      { // finished logging
        // finish
        mission_vel_ref = regul_balvel_step_to;
        missionState = 3;
      }
      break;
    case 3:
      // continue until log buffer is full
      if (not loggerLogging())
      { // finished logging
        // finish
        missionState = 999;
      }
      break;
    default:
      // no more state, stop motors
      motorAnkerVoltage[0] = 0;
      motorAnkerVoltage[1] = 0;
      motorSetEnable(false, false);
      // go back to - try again.
      // if button is released
      if (not button)
        missionState = 0;
      break;
  }
}



// void regulatorInit1(float kp, float ti, float td, float al, float * zu, float * ze)
// {
//   const float T = 0.001;
//   if (ti == 0.0 and td == 0.0)
//   { // P-regulator
//     zu[1] = 0.0;
//     zu[2] = 0.0;
//     ze[0] = kp;
//     ze[1] = 0.0;
//     ze[2] = 0.0;
//   }
//   else if (td == 0.0)
//   {
//     zu[0] = 2 * ti;
//     zu[1] = -1;
//     zu[2] = 0;
//     ze[0] = kp * (T + 2 * ti) / zu[0];
//     ze[1] = kp * (T - 2 * ti) / zu[0];
//     ze[2] = 0;
//   }
//   else if (ti == 0.0)
//   {
//     zu[0] = 2 * al * td + T;
//     zu[1] = T - 2 * al * td;
//     zu[2] = 0;
//     ze[0] = kp * (T + 2 * td) / zu[0];
//     ze[1] = kp * (T - 2 * td) / zu[0];
//     ze[2] = 0;
//   }
//   else
//   {
//     zu[0] =  4 * al * td * ti + 2 * T * ti;
//     zu[1] = -8 * al * td * ti / zu[0];
//     zu[2] = (4 * al * td * ti - 2 * T * ti) / zu[0];
//     ze[0] = kp * (T * (T + 2 * td + 2 * ti) + 4  * td * ti) / zu[0];
//     ze[1] = kp * (2* T * T - 8 * td * ti) / zu[0];
//     ze[2] = kp * (T * (T - 2* td - 2* ti) + 4 * td * ti) / zu[0];
//   }
//   regVelELeft[1] = 0;
//   regVelELeft[2] = 0;
//   regVelERight[1] = 0;
//   regVelERight[2] = 0;
//   regVelUDLeft[1] = 0;
//   regVelUDLeft[2] = 0;
//   regVelERight[1] = 0;
//   regVelERight[2] = 0;
// }

/**
 * Initialize discrete regulators from continious parameters
 * input:
 * \param kp is proportional gain
 * \param ti is time constant for zero in I-term
 * \param td is time constant in lead zero
 * \param al is relative position of pole in lead term
 * output:
 * \param zu is pointer to parameters for denominator in z-expression for lead term
 * \param ze is pointer to parameters for numerator for z-expression for lead term
 * \param zui is pointer to parameters for denominator in z-expression for I-term
 * \param zei is pointer to parameters for numerator for z-expression for I-term
 */
// void regulatorInit2(float kp, float ti, float td, float al, float * zu, float * ze, float * zui, float * zei)
// {
//   const float T = 0.001;
//   if (td <= 0.0 or al <= 0.0)
//   { // P-regulator
//     zu[0] = 1.0; // denominator
//     zu[1] = 0.0;
//     ze[0] = kp;  // numerator
//     ze[1] = 0.0;
//   }
//   else
//   { // include lead term
//     /*
//      * Gzd2:=expand(Gzd*z^(-1));
//      *                                 2 al td   T
//      *                   2 al td + T - ------- + -
//      *                                    z      z
//      * Gzn2:=expand(Gzn*z^(-1));
//      *                                 T   2 td
//      *                      T + 2 td + - - ----
//      *                                 z    z  
//      */
//     zu[0] = 2 * al * td + T;           // denominator (this tern is normalized away)
//     zu[1] = (T - 2 * al * td) / zu[0];
//     ze[0] = kp * (T + 2 * td) / zu[0]; // numerator
//     ze[1] = kp * (T - 2 * td) / zu[0];
//   }
//   if (ti > 0.0)
//   { // engage the integrator
//     /*
//      * Gzd2:=expand(Gzd*z^(-1));
//      *                                 2 ti
//      *                          2 ti - ----
//      *                                  z  
//      * Gzn2:=expand(Gzn*z^(-1));
//      *                                 T   2 ti
//      *                      T + 2 ti + - - ----
//      *                                 z    z  
//      */
//     zui[0] = 2 * ti; // denominator
//     zui[1] = -1;
//     zei[0] = (T + 2 * ti) / zui[0]; // numerator
//     zei[1] = (T - 2 * ti) / zui[0];
//   }
//   else
//   { // no added value from integrator
//     zui[0] = 1;
//     zui[1] = 0;
//     zei[0] = 0;
//     zei[1] = 0;
//   }
// }

/**
 * Initialize discrete regulators from continious parameters
 * input:
 * \param kp is proportional gain
 * \param ti is time constant for zero in I-term
 * \param td is time constant in lead zero
 * \param al is relative position of pole in lead term
 * \param zeta is damping of complex pole pair
 * output:
 * \param zu is pointer to parameters for denominator in z-expression for lead term
 * \param ze is pointer to parameters for numerator for z-expression for lead term
 * \param zui is pointer to parameters for denominator in z-expression for I-term
 * \param zei is pointer to parameters for numerator for z-expression for I-term
 */
void regulatorInitComplexLead(float kp, float ti, float td, float al, float zeta, float * zu, float * ze, float * zui, float * zei)
{
  const float T = 0.001;
  if (td <= 0.0 or al <= 0.0)
  { // P-regulator
    zu[0] = 1.0; // denominator
    zu[1] = 0.0;
    ze[0] = kp;  // numerator
    ze[1] = 0.0;
  }
  else if (zeta <= 0.0)
  { // include lead term
    /*
      * Gzd2:=expand(Gzd*z^(-1));
      *                                 2 al td   T
      *                   2 al td + T - ------- + -
      *                                    z      z
      * Gzn2:=expand(Gzn*z^(-1));
      *                                 T   2 td
      *                      T + 2 td + - - ----
      *                                 z    z  
      */
    zu[0] = 2 * al * td + T; // denominator 
    zu[1] = (T - 2 * al * td) / zu[0];
    ze[0] = kp * (T + 2 * td) / zu[0]; // numerator
    ze[1] = kp * (T - 2 * td) / zu[0];
  }
  else
  { // complex lead term
    /* Denominator
     * Gzd2:=expand(Gzd*z^(-2));
     *                                             2   2      2
     *                            2   2    2   8 al  td    2 T 
     *       4 al td zeta T + 4 al  td  + T  - --------- + ----
     *                                             z        z  
     * 
     *                                 2   2    2
     *            4 al td zeta T   4 al  td    T 
     *          - -------------- + --------- + --
     *                   2             2        2
     *                  z             z        z 
     * Numerator
     *    Gzn2:=expand(Gzn*z^(-2));
     *                              2    2            
     *              2            2 T    T    2 T td
     *        Kp ( T  + 2 T td + ---- + -- - ------ )
     *                            z      2      2    
     *                                  z      z     
     */
    zu[0] = 4 * al * td * zeta * T + 4 * al*al * td*td + T*T; // denominator (k)
    zu[1] = (2*T*T - 8 * al*al * td*td)/zu[0];
    zu[2] = (-4* al * td * zeta * T + 4 * al*al * td*td + T*T)/zu[0];
    ze[0] = kp * (T*T + 2 * T * td) / zu[0]; // numerator
    ze[1] = kp * (2 * T*T) / zu[0];
    ze[2] = kp * (T*T - 2 * T * td) / zu[0];
  }
  if (ti > 0.0)
  { // engage the integrator
    /*
     * GC(s) = Kp * ( 1/(tau_i s + 1) + 1)
     * Gzd2:=expand(Gzd*z^(-1));
     *                                 2 ti
     *                          2 ti - ----
     *                                  z  
     * Gzn2:=expand(Gzn*z^(-1));
     *                                 T
     *                             T + -
     *                                 z
     * 
     */
    zui[0] = 2 * ti; // deniminator
    zui[1] = -1;
    zei[0] = (T) / zui[0]; // numerator
    zei[1] = (T) / zui[0];
  }
  else
  { // no added value from integrator
    zui[0] = 1;
    zui[1] = 0;
    zei[0] = 0;
    zei[1] = 0;
  }
}

/**
 * simpel filter 2 order */
void filt1order(float * x, float * y, float * parX, float * parY)
{
    y[0] = -parY[1] * y[1] + 
            parX[0] * x[0] + parX[1] * x[1];
}

/**
 * simpel filter 2 order */
void filt2order(float * x, float * y, float * parX, float * parY)
{
  y[0] = -parY[1] * y[1] - parY[2] * y[2] + 
          parX[0] * x[0] + parX[1] * x[1] + parX[2] * x[2];
}



/**
 * Do control of wheel velocity
 * \param ref is desired velocity (rad/sec)
 * \param measured is measured velocity (rad/sec)
 * \param left if trur, then use left dataset, else use right */
void regulWheelVel(float ref, float measured, bool left)
{
  //regVelELeft, regVelUDLeft, regVelUILeft,  regVelULeft
  if (left)
  { 
    if (regul_vel_LeadFwd)
    { // calculate new error
      regVelELeft[0] = (ref - measured) * regul_vel_kp;
      // lead in fwd chain
      // filt 1 order ( input array, output array, x-params (numerator), y-params(denom))
      filt1order(regVelELeft, regVelUDLeft, regVelParE, regVelParU);
      // integral part - output of lead is input to I
      filt1order(regVelUDLeft, regVelUILeft, regVelParEI, regVelParUI);
    }
    else
    { // lead in measured path
      regVelMLeft[0] = measured;
      filt1order(regVelMLeft, regVelUDLeft, regVelParE, regVelParU);
      // calculate error
      regVelELeft[0] = (ref - regVelUDLeft[0]) * regul_vel_kp;
      // integral part - output of lead is input to I
      filt1order(regVelELeft, regVelUILeft, regVelParEI, regVelParUI);
      // make one step older
      regVelMLeft[1] = regVelMLeft[0];
    }
    // limit I
    if (regVelUILeft[0] > regul_vel_i_limit)
      regVelUILeft[0] = regul_vel_i_limit;
    else if (regVelUILeft[0] < -regul_vel_i_limit)
      regVelUILeft[0] = -regul_vel_i_limit;
    // sum P-lead and I them
    if (regul_vel_LeadFwd)
      regVelULeft[0] = regVelUDLeft[0] + regVelUILeft[0];
    else
      regVelULeft[0] = regVelELeft[0] + regVelUILeft[0];
    // make one step older
    regVelELeft[1] = regVelELeft[0];
    regVelUDLeft[1] = regVelUDLeft[0];
    regVelUILeft[1] = regVelUILeft[0];      
  }
  else
  {
    if (regul_vel_LeadFwd)
    { // calculate new error
      regVelERight[0] = (ref - measured) * regul_vel_kp;
      // lead in fwd chain
      // filt 1 order ( input array, output array, x-params (numerator), y-params(denom))
      filt1order(regVelERight, regVelUDRight, regVelParE, regVelParU);
      // integral part - output of lead is input to I
      filt1order(regVelUDRight, regVelUIRight, regVelParEI, regVelParUI);
    }
    else
    { // lead in measured path
      regVelMRight[0] = measured;
      filt1order(regVelMRight, regVelUDRight, regVelParE, regVelParU);
      // calculate error
      regVelERight[0] = (ref - regVelUDRight[0]) * regul_vel_kp;
      // integral part - output of lead is input to I
      filt1order(regVelERight, regVelUIRight, regVelParEI, regVelParUI);
      // make one step older
      regVelMRight[1] = regVelMRight[0];
    }
    // limit I
    if (regVelUIRight[0] > regul_vel_i_limit)
      regVelUIRight[0] = regul_vel_i_limit;
    else if (regVelUIRight[0] < -regul_vel_i_limit)
      regVelUIRight[0] = -regul_vel_i_limit;
    // sum P-lead and I them
    if (regul_vel_LeadFwd)
      regVelURight[0] = regVelUDRight[0] + regVelUIRight[0];
    else
      regVelURight[0] = regVelERight[0] + regVelUIRight[0];
    // make one step older
    regVelERight[1] = regVelERight[0];
    regVelUDRight[1] = regVelUDRight[0];
    regVelUIRight[1] = regVelUIRight[0];      
  }
}

/**
 * Do control of wheel velocity
 * \param ref is desired velocity (rad/sec)
 * \param measured is measured velocity (rad/sec)
 *  */
void regulSteer(float ref, float measured)
{
  //regVelELeft, regVelUDLeft, regVelUILeft,  regVelULeft
  if (regul_turn_LeadFwd)
  { // calculate new error
    regTurnE[0] = ref - measured; // both angles
    if (regTurnE[0] > M_PI)
      regTurnE[0] -= 2.0 * M_PI;
    else if (regTurnE[0] < - M_PI)
      regTurnE[0] += 2.0 * M_PI;
    regTurnE[0] *= regul_turn_kp;
    // lead in fwd chain
    // filt 1 order ( input array, output array, x-params (numerator), y-params(denom))
    filt1order(regTurnE, regTurnUD, regTurnParE, regTurnParU);
    // integral part - output of lead is input to I
    filt1order(regTurnUD, regTurnUI, regTurnParEI, regTurnParUI);
  }
  else
  { // lead in measured path
    regTurnM[0] = measured;
    // test if the measured has changed rotation since the history version
    if (regTurnM[0] - regTurnM[1] > M_PI)
      regTurnM[1] += 2.0 * M_PI;
    else if (regTurnM[0] - regTurnM[1] < -M_PI)
      regTurnM[1] -= 2.0 * M_PI;
    // make Lead filtering
    filt1order(regTurnM, regTurnUD, regTurnParE, regTurnParU);
    // ensure also that measured and reference are in same rotation
    regTurnE[0] = ref - measured;
    if (ref - measured > M_PI)
      ref -= 2.0 * M_PI;
    else if (ref - measured < - M_PI)
      ref += 2.0 * M_PI;
    // then the difference should be valid also after the lead filter
    regTurnE[0] = (ref - regTurnUD[0]) * regul_turn_kp;
    // integral part - output of lead is input to I
    filt1order(regTurnE, regTurnUI, regTurnParEI, regTurnParUI);
    // make one step older
    regTurnM[1] = regTurnM[0];
  }
  // limit I
  if (regul_turn_i_limit > 1e-5)
  { // integration is to be limited
    if (regTurnUI[0] > regul_turn_i_limit)
      regTurnUI[0] = regul_turn_i_limit;
    else if (regTurnUI[0] < -regul_turn_i_limit)
      regTurnUI[0] = -regul_turn_i_limit;
  }
  // sum P-lead/P and I term
  if (regul_turn_LeadFwd)
    regTurnU[0] = regTurnUD[0] + regTurnUI[0];
  else
    regTurnU[0] = regTurnE[0] + regTurnUI[0];
  // make one step older
  regTurnE[1] = regTurnE[0];
  regTurnUD[1] = regTurnUD[0];
  regTurnUI[1] = regTurnUI[0];      
}

///////////////////////////////////////////////////////

void regulBal(float ref, float measured)
{
  if (regul_bal_LeadFwd)
  { // lead in fwd, so first error and Kp
    regBalE[0] = (ref - measured) * regul_bal_kp;
    // then lead part filter
    filt1order(regBalE, regBalUD, regBalParE, regBalParU);
    // integral part - output of lead is input to I
    filt1order(regBalUD, regBalUI, regBalParEI, regBalParUI);
  }
  else
  { // lead in measured branch
    regBalM[0] = measured;
    // lead part
    filt1order(regBalM, regBalUD, regBalParE, regBalParU);
    // 
    regBalE[0] = (ref - regBalUD[0]) * regul_bal_kp;
    // integral part - output of lead is input to I
    filt1order(regBalE, regBalUI, regBalParEI, regBalParUI);
    // save old M value
    regBalM[1] = regBalM[0];
  }
  // integration limit - if active
  if (regul_bal_i_limit > 1e-5)
  { // implement limit
    if (regBalUI[0] > regul_bal_i_limit)
      regBalUI[0] = regul_bal_i_limit;
    else if (regBalUI[0] < -regul_bal_i_limit)
      regBalUI[0] = -regul_bal_i_limit;
  }
  // sum P-lead/P and I term
  if (regul_bal_LeadFwd)
    regBalU[0] = regBalUD[0] + regBalUI[0];
  else
    regBalU[0] = regBalE[0] + regBalUI[0];
  // make one step older
  regBalE[1] = regBalE[0];
  regBalUD[1] = regBalUD[0];
  regBalUI[1] = regBalUI[0];      
}

///////////////////////////////////////////////////////

void regulBalVel(float ref, float measured)
{
  if (regul_balVel_LeadFwd)
  { // lead in fwd, so first error and Kp
    regBalVelE[0] = (ref - measured) * regul_balvel_kp;
    // then lead part filter
    filt1order(regBalVelE, regBalVelUD, regBalVelParE, regBalVelParU);
    // integral part - output of lead is input to I
    filt1order(regBalVelUD, regBalVelUI, regBalVelParEI, regBalVelParUI);
  }
  else
  { // lead in measured branch
    regBalVelM[0] = measured;
    // lead part
    filt1order(regBalVelM, regBalVelUD, regBalVelParE, regBalVelParU);
    // 
    regBalVelE[0] = (ref - regBalVelUD[0]) * regul_balvel_kp;
    // integral part - output of lead is input to I
    filt1order(regBalVelE, regBalVelUI, regBalVelParEI, regBalVelParUI);
    // save old M value
    regBalVelM[1] = regBalVelM[0];
  }
  // integration limit - if active
  if (regul_balvel_i_limit > 1e-5)
  { // implement limit
    if (regBalVelUI[0] > regul_balvel_i_limit)
      regBalVelUI[0] = regul_balvel_i_limit;
    else if (regBalVelUI[0] < -regul_balvel_i_limit)
      regBalVelUI[0] = -regul_balvel_i_limit;
  }
  // sum P-lead/P and I term
  if (regul_balVel_LeadFwd)
    regBalVelU[0] = regBalVelUD[0] + regBalVelUI[0];
  else
    regBalVelU[0] = regBalVelE[0] + regBalVelUI[0];
  // make one step older
  regBalVelE[1] = regBalVelE[0];
  regBalVelUD[1] = regBalVelUD[0];
  regBalVelUI[1] = regBalVelUI[0];      
}

/**
 * to control as a P, P-Lead with an optional I-term
 * \param e is error and historic error
 * \param ud is the storage for the result of the P or P-Lead part of controller (size 2 floats)
 * \param ui is the storage for the result of the integral part of controller (size 2 floats)
 * \param u is the output of the controller u[0] (and storage for the last controller value 
 * \param i_limit is maximum integration value, if 0.0 (or negative) then no limit 
 * \param par is index to controller parameters: 0:velocity, 1: turn, 2: balance, 3: balance velocity */
void regulatorPILead(float * e, float * ud, float * ui, float * u, float i_limit, int par)
{
  static int a = 1000;
  switch (par)
  {
    case 0: // motor velocity controller
//       if (regul_vel_LeadFwd)
//       {
//         e[0] = ref - measured[0];
//         ud[0] = filt1order(e, ud, regVelParE, regVelParU);
// //         ud[0] = -regVelParU[1] * ud[1] + 
// //                 (regVelParE[0] * e[0] + 
// //                 regVelParE[1] * e[1]);
//       }
//       else
//       {
//         e[0] = -regVelParU[1] * ud[1] + 
//                 (regVelParE[0] * measured[0] + 
//                  regVelParE[1] * measured[1]);
//         ikke rigtigt godt
//         skal nok have funktion for 1 transfer function med in og out som array
//       }
//       //
//       // integrator used Kp-Lead result 'u' as input
//       ui[0] = -regVelParUI[1] * ui[1] + 
//               (regVelParEI[0] * ud[0] + 
//                regVelParEI[1] * ud[1]);
      break;
    case  1: // turn controller
      ud[0] = -regTurnParU[1] * ud[1] + 
              (regTurnParE[0] * e[0] + 
               regTurnParE[1] * e[1]);
      //
      // integrator used Kp-Lead result 'u' as input
      ui[0] = -regTurnParUI[1] * ui[1] + 
              (regTurnParEI[0] * ud[0] + 
               regTurnParEI[1] * ud[1]);
      break;
    case  2: // balance controller
      ud[0] = -regBalParU[1] * ud[1] + 
              (regBalParE[0] * e[0] + 
               regBalParE[1] * e[1]);
      //
      // integrator used Kp-Lead result 'u[0]' as input
      ui[0] = -regBalParUI[1] * ui[1] + 
              (regBalParEI[0] * ud[0] + 
               regBalParEI[1] * ud[1]);
      // debug
      if (a < 10 and hbTimerCnt % 100 < 5)
      { // balance control fails if this "if" is missing !!!!!
        // I fail to see why.
        const int MSL = 200;
        char s[MSL];
        snprintf(s, MSL, "# debug bal ctrl: hb %.3f e[0]=%.2f, ud[0]=%5.2f, ui[0]=%5.2f \n", time, e[0],  ud[0], ui[0]);
        usb_send_str(s);
      }
      // debug end
      break;
    case  3: // velocity control when balancing - optional use complex poles in lead
      ud[0] = -regBalVelParU[1] * ud[1] -
               regBalVelParU[2] * ud[2] + 
               regBalVelParE[0] * e[0] + 
               regBalVelParE[1] * e[1] + 
               regBalVelParE[2] * e[2];
      // limit control - before integrator
      if (i_limit > 0.0)
      { // limit to less than integrator
        const float pLimitFac = 0.3;
        if (ud[0] > i_limit * pLimitFac)
          ud[0] = i_limit * pLimitFac;
        else if (ud[0] < -i_limit * pLimitFac)
          ud[0] = -i_limit * pLimitFac;
      }
      // integrator used Kp-Lead result 'u' as input
      ui[0] = -regBalVelParUI[1] * ui[1] + 
              (regBalVelParEI[0] * ud[0] + 
               regBalVelParEI[1] * ud[1]);
      // remember extra term
      ud[2] = ud[1];
      e[2] = e[1];
      break;
    default:
      break;
  }      
  if (i_limit > 0.0)
  { // limit possible integration term
    if (ui[0] > i_limit)
      ui[0] = i_limit;
    else if (ui[0] < -i_limit)
      ui[0] = -i_limit;
  }
  // add Kp-Lead term with I-term
  u[0] = ud[0] + ui[0];
  // save for next iteration
  e[1] = e[0];
  ud[1] = ud[0];
  ui[1] = ui[0];
}

///////////////////////////////////////////////////

void regulatorVelBoth()
{ // make speed control of both motors
  if (missionState > 1)
  { // we are in a mission
    float velRef, balURef;
         regul_bal_use=1;
    if (regul_bal_use and mission > 1)
    { // do not use mission velocity, commes from balance control
      velRef = 0.0;
      // no acceleration limit on balance control
      balURef = regul_bal_uvel;
    }
    else
    { // use mission velocity as input - acc limited
      velRef = mission_vel_ref;
      balURef = 0.0;
    }
    regul_vel_use=1;
    if (regul_vel_use)
    { // implement velocity control on motor voltage
      // acceleration control is here (if requested)
      float accSampleLimit = regul_acc_limit * SAMPLETIME / odoWheelRadius[0];
      if (accSampleLimit < 1e-5)
        // not too small to avoid number errors
        // max speed approx 2m/s and 6-7 significalt digits
        accSampleLimit = 1e-5;
      if (regul_acc_limit < 98)
      { // usable acceleration limit
        // left wheel
        float diff = velRef - regul_turn_vel_reduc[0] - regul_vel_ref[0];
        if (diff > accSampleLimit)
          regul_vel_ref[0] += accSampleLimit;
        else if (diff < -accSampleLimit)
          regul_vel_ref[0] -= accSampleLimit;
        else
          regul_vel_ref[0] = velRef - regul_turn_vel_reduc[0];
        // right wheel
        diff = velRef - regul_turn_vel_reduc[1] - regul_vel_ref[1];
        if (diff > accSampleLimit)
          regul_vel_ref[1] += accSampleLimit;
        else if (diff < -accSampleLimit)
          regul_vel_ref[1] -= accSampleLimit;
        else
          regul_vel_ref[1] = velRef - regul_turn_vel_reduc[1];
      }
      else
      { // no acceleration limit requested
        regul_vel_ref[0] = velRef - regul_turn_vel_reduc[0];
        regul_vel_ref[1] = velRef - regul_turn_vel_reduc[1];
      }
//       if ((hbTimerCnt % 100) == 50)
//       {
//         const int MSL = 100;
//         char s[MSL];
//         snprintf(s, MSL, "# vel both velref %g %g = %g - %g %g\n", regul_vel_ref[0], regul_vel_ref[1], velRef, regul_turn_vel_reduc[0],regul_turn_vel_reduc[1]);
//         usb_write(s);
//       }
      // add balance value without acceleration limit
      regul_vel_tot_ref[0] = regul_vel_ref[0] + balURef;
      regul_vel_tot_ref[1] = regul_vel_ref[1] + balURef;
      regul_vel_tot_ref[0] =  balURef;
      regul_vel_tot_ref[1] =  balURef;
     
      // calculate regulator error
      regulWheelVel(regul_vel_tot_ref[0], wheelVelocityEst[0], true);  // left
      regulWheelVel(regul_vel_tot_ref[1], wheelVelocityEst[1], false); // right
//       regVelELeft[0]  = regul_vel_tot_ref[0] - wheelVelocityEst[0];
//       regVelERight[0] = regul_vel_tot_ref[1] - wheelVelocityEst[1];
//       // run controller with separate integrator limit
//       regulatorPILead(regVelELeft, regVelUDLeft, regVelUILeft,  regVelULeft, regul_vel_i_limit, 0);
//       regulatorPILead(regVelERight, regVelUDRight, regVelUIRight, regVelURight, regul_vel_i_limit, 0);
      // transefer to motor voltage
      motorAnkerVoltage[0] = regVelULeft[0];
      motorAnkerVoltage[1] = regVelURight[0];
    }
    else
    { // store also in regul_vel_tot_ref for proper logging
      regul_vel_tot_ref[0] = velRef + balURef - regul_turn_vel_reduc[0];
      regul_vel_tot_ref[1] = velRef + balURef - regul_turn_vel_reduc[1];
      // and then direct to motor voltage
      motorAnkerVoltage[0] = regul_vel_tot_ref[0];
      motorAnkerVoltage[1] = regul_vel_tot_ref[1];
    }
  }
  else if (regVelELeft[0] != 0.0)
  { // clean up after last mission
    regVelELeft[1] = 0;
//    regVelELeft[2] = 0;
    regVelERight[1] = 0;
//    regVelERight[2] = 0;
    regVelUDLeft[1] = 0;
    regVelUDRight[1] = 0;
    regVelUILeft[1] = 0;
    regVelUIRight[1] = 0;
    //    regVelERight[2] = 0;
    motorAnkerVoltage[0] = 0;
    motorAnkerVoltage[1] = 0;
    regul_vel_ref[0] = 0.0;
    regul_vel_ref[1] = 0.0;
    motorSetEnable(false, false);
    zeroVelEstimator();
  }
}

/**
 * turn controller */
void regulator_turn()
{ // turn regulator - using pose heading and main mission turn reference
  if (missionState > 0)
  { // we are running and mission, 
    if (mission_turn_do)
    { // handle turns by difference in wheel speed only
      if (misLine->turn > 0)
      { // regulate left wheel
        regul_turn_vel_reduc[0] = mission_vel_ref * odoWheelBase / 
                             (mission_turn_radius + odoWheelBase / 2.0);
        regul_turn_vel_reduc[1] = 0;
      }
      else
      { // regulate left wheel
        regul_turn_vel_reduc[1] = mission_vel_ref * odoWheelBase / 
                             (mission_turn_radius + odoWheelBase / 2.0);
        regul_turn_vel_reduc[0] = 0;
      }
    }
    else
    { // this controller keeps heading during straight path only
//       regTurnE[0]  = mission_turn_ref - pose[2];
//       if (regTurnE[0] > M_PI)
//         regTurnE[0] -= 2.0 * M_PI;
//       else if (regTurnE[0] < - M_PI)
//         regTurnE[0] += 2.0 * M_PI;
      if (regul_turn_use)
      { // turn controller effective
        regulSteer(mission_turn_ref, pose[2]);
//        regulatorPILead(regTurnE, regTurnUD, regTurnParUI,  regTurnU, regul_turn_i_limit, 1);
        regul_turn_vel_reduc[0] =  regTurnU[0];
        regul_turn_vel_reduc[1] = -regTurnU[0];
      }
      else
      {  // open loop control
        regul_turn_vel_reduc[0]  =  mission_turn_ref;
        regul_turn_vel_reduc[1]  = -mission_turn_ref;
      }
//       if ((hbTimerCnt % 100) < 2)
//       {
//         const int MSL = 220;
//         char s[MSL];
//         snprintf(s, MSL, "# turn ref=%g, h=%g, e=%g, reduc %g %g\n", mission_turn_ref, pose[2], regTurnE[0],  regul_turn_vel_reduc[0],regul_turn_vel_reduc[1]);
//         usb_write(s);
//       }
    }
//     if ((hbTimerCnt % 100) == 2)
//     {
//       const int MSL = 100;
//       char s[MSL];
//       snprintf(s, MSL, "# turn_reduc %g %g, use %d, do %d\n", regul_turn_vel_reduc[0],regul_turn_vel_reduc[1], regul_turn_use, mission_turn_do);
//       usb_write(s);
//     }
  }
  else
  { // no mission active - reset controller
    mission_turn_ref = 0.0;
    regTurnE[1] = 0;
    regTurnUD[1] = 0;
    regTurnUI[1] = 0;
    regul_turn_vel_reduc[0] = 0.0;
    regul_turn_vel_reduc[1] = 0.0;
  }
}


/**
 * balance controller and mission velocity through balance
 * velocity is acceleration limited.
 * Balance control 
 */
void regulator_bal()
{   if (missionState <2) {intgbal=0;posoff=wheelPosition[0];tilt0=pose[3];} 
    if (missionState > 1)
    { // we are running
         
        intgbal+= 0.00125*((pose[3]+regul_bal_i_limit-1.0)*regul_bal_kp +gyroTilt*regul_bal_ti + wheelVelocity[0]*regul_bal_td +(wheelPosition[0]-posoff)*regul_bal_alpha);
           regul_bal_uvel=intgbal;
      //intgbal+= 0.00125*((pose[3]+regul_bal_i_limit-1.0)*regul_bal_kp  + wheelVelocity[0]*regul_bal_td +(wheelPosition[0]-posoff)*regul_bal_alpha);
      //regul_bal_uvel=intgbal+(pose[3]-tilt0)*regul_bal_ti;

    }
    else
    { // make sure all old values are zero
      regBalE[1] = 0.0;
      regBalUD[1] = 0.0;
      regBalUI[1] = 0.0;
      regBalVelE[1] = 0.0;
      regBalVelUI[1] = 0.0;
      regul_balvel_reduc = (wheelVelocityEst[0] + wheelVelocityEst[1])/ 2.0;
    }
}


/**
 * This function is called every time it is time to do a new control calculation
 * Before the call the motor control values (motorCtrl) are set to 0.0 indication zero speed
 * To make the motor go, the motor Idle must be set to false (0), and
 * The motorCtrl value(s) set to a value between +1.0 and -1.0, positive for forward.
 * In short intervals the motorCtrl values may go as high as +12.0 to -12.0, this will
 * give the motor up to +/- 12 V - twice the voltage it is rated for. This could be used for 
 * fast acceleration. 
 * The new motor values are implemented once this functon returns. 
 * */ 
void controlTick(void)
{ // NB! must return fast, i.e. no long processing here, except
  // after end of mission (default state)
  // usb_serial_write(".", 1);
  if (missionStateLast != missionState or misLineNum != misLineNumLast)
  {
    sendStatusMission();
    missionStateLast = missionState;
    misLineNumLast = misLineNum;
  }
  if (missionState > 0 and missionStop)
    // switch to default state - to stop mission
    missionState = -1;
  switch (mission)
  {
    case 0: 
      motor_vel_gui_step(); 
      regulatorVelBoth();
      break;
    case 1: 
      mission_gui_turn_step(); 
      regulator_turn();
      regulatorVelBoth();
      break;
    case 2:
      // ballance step
      balance_test();
      regulator_bal();
      //regulator_turn();
      regulatorVelBoth();
      break;
    case 3:
      // Mission with no regulator
      // or turn regulator only
      user_mission();
      if (misLine != NULL)
      {
        if (regul_bal_use)
          regulator_bal();
        regulator_turn();
        regulatorVelBoth();
      }
      break;
    default:
      mission = 0;
      break;
  }  
}

void initRegulators()
{
  // Init z-1 values for velocity
  regVelELeft[1] = 0;
  regVelERight[1] = 0;
  regVelUDLeft[1] = 0;
  regVelUDRight[1] = 0;
  // integral controller
  regVelUILeft[1] = 0;
  regVelUIRight[1] = 0;
  //
  // Init z-1 values for turn
  regTurnE[1] = 0;
  regTurnUD[1] = 0;
  regTurnUI[1] = 0;
  // Init z-1 values for bal
  regBalE[1] = 0;
  regBalUD[1] = 0;
  regBalUI[1] = 0;
  // Init z-1 values for bal
  regBalVelE[1] = 0;
  regBalVelE[2] = 0;
  regBalVelUD[1] = 0;
  regBalVelUD[2] = 0;
  regBalVelUI[1] = 0; 
  // velocity regulator init
  regulatorInitComplexLead(1.0, regul_vel_ti, regul_vel_td, regul_vel_alpha, 0.0,
                 regVelParU, regVelParE, regVelParUI, regVelParEI);
  // turn regulator
  regulatorInitComplexLead(regul_turn_kp, regul_turn_ti, regul_turn_td, regul_turn_alpha, 0.0,
                 regTurnParU, regTurnParE, regTurnParUI, regTurnParEI);
  // balance regulator init
  regulatorInitComplexLead(regul_bal_kp, regul_bal_ti, regul_bal_td, regul_bal_alpha, 0.0,
                 regBalParU, regBalParE, regBalParUI, regBalParEI);
  // balance regulator init
  // with (possible) complex pole pair in lead
  regulatorInitComplexLead(regul_balvel_kp, regul_balvel_ti, regul_balvel_td, regul_balvel_alpha, regul_balvel_zeta, 
                 regBalVelParU, regBalVelParE, regBalVelParUI, regBalVelParEI);
}

bool setRegulator(const char * line)
{
  bool used = false;
  if (line[2] == '=' and line[0] == 'r')
  { // one character assignment command
    char * p1 = (char *)(&line[3]);
    if (*p1 >= ' ')
    {
      used = true;
      switch (line[1])
      { // rt= use kp td alpha
        case 't':
          regul_turn_use = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            regul_turn_kp = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_ti = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_td = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_alpha = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_i_limit = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_step_time_on = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_step_time_off = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_step_val = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_turn_step_vel = strtof(p1, &p1);
          if (*p1 >= ' ')
            // use estimated velocity
            regul_turn_LeadFwd = strtol(p1, &p1, 10);
          break;
        case 'v':
          regul_vel_use = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            regul_vel_kp = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_ti = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_td = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_alpha = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_i_limit = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_step_time = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_step_from = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_vel_step_to = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_acc_limit = strtof(p1, &p1);
          if (*p1 >= ' ')
            // use estimated velocity
            regul_vel_est = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            // use estimated velocity
            regul_vel_LeadFwd = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            // use estimated velocity
            max_motor_voltage = strtof(p1, &p1);
          // void regulatorInit(float kp, float ti, float td, float al, float * zu, float * ze)
          break;
        case 'b':
          regul_bal_use = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            regul_bal_kp = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_bal_ti = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_bal_td = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_bal_alpha = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_bal_i_limit = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_step_time = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_step_from = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_step_to = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_use = strtol(p1, &p1, 10);
          if (*p1 >= ' ')
            regul_bal_LeadFwd = strtol(p1, &p1, 10);
          break;
        case 'm':
          regul_balvel_kp = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_ti = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_td = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_alpha = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_zeta = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balvel_i_limit = strtof(p1, &p1);
          if (*p1 >= ' ')
            regul_balVel_LeadFwd = strtol(p1, &p1, 10);
          break;
        default:
          used = false;
      }      
    }
  }
  if (used)
    // initialize regulator
    initRegulators();
  return used;
}

/**
 * save controller configuration to EE Prom */
void eePromSaveCtrl()
{ // mission
  eePromPush(mission);
  // vel ctrl
  eePromPush(regul_vel_use);
  eePromPushFloat(regul_vel_kp);
  eePromPushFloat(regul_vel_ti);
  eePromPushFloat(regul_vel_td);
  eePromPushFloat(regul_vel_alpha);
  eePromPushFloat(regul_vel_i_limit);
  eePromPushFloat(regul_vel_step_time);
  eePromPushFloat(regul_vel_step_from);
  eePromPushFloat(regul_vel_step_to);
  eePromPush(regul_vel_est);
  eePromPush(regul_vel_LeadFwd);
  eePromPushFloat(max_motor_voltage);
  // turn
  eePromPush(regul_turn_use);
  eePromPushFloat(regul_turn_kp);
  eePromPushFloat(regul_turn_ti);
  eePromPushFloat(regul_turn_td);
  eePromPushFloat(regul_turn_alpha);
  eePromPushFloat(regul_turn_i_limit);
  eePromPushFloat(regul_turn_step_time_on);
  eePromPushFloat(regul_turn_step_time_off);
  eePromPushFloat(regul_turn_step_val);
  eePromPushFloat(regul_turn_step_vel);
  eePromPushFloat(regul_acc_limit);
  eePromPush(regul_turn_LeadFwd);
  // balance ctrl
  eePromPush(regul_bal_use);
  eePromPushFloat(regul_bal_kp);
  eePromPushFloat(regul_bal_ti);
  eePromPushFloat(regul_bal_td);
  eePromPushFloat(regul_bal_alpha);
  eePromPushFloat(regul_bal_i_limit);
  eePromPushFloat(regul_bal_u_limit);
  eePromPushFloat(regul_balvel_step_time);
  eePromPushFloat(regul_balvel_step_from);
  eePromPushFloat(regul_balvel_step_to);
  eePromPush(regul_balvel_use);
  eePromPush(regul_bal_LeadFwd);
  // mission balance velocity ctrl
  eePromPushFloat(regul_balvel_kp);
  eePromPushFloat(regul_balvel_ti);
  eePromPushFloat(regul_balvel_td);
  eePromPushFloat(regul_balvel_zeta);
  eePromPushFloat(regul_balvel_alpha);
  eePromPushFloat(regul_balvel_i_limit);
  eePromPushFloat(regul_balvel_u_limit);
  eePromPush(regul_balVel_LeadFwd);
}
/**
 * load controller configuration from EE Prom
 * same order as when saved
 */
void eePromLoadCtrl()
{ // mission
  mission = eePromRead();
  // vel ctrl
  regul_vel_use = eePromRead();
  regul_vel_kp = eePromReadFloat();
  regul_vel_ti = eePromReadFloat();
  regul_vel_td = eePromReadFloat();
  regul_vel_alpha = eePromReadFloat();
  regul_vel_i_limit = eePromReadFloat();
  regul_vel_step_time = eePromReadFloat();
  regul_vel_step_from = eePromReadFloat();
  regul_vel_step_to = eePromReadFloat();
  regul_vel_est = eePromRead();
  regul_vel_LeadFwd = eePromRead();
  max_motor_voltage = eePromReadFloat();
  // turn
  regul_turn_use = eePromRead();
  regul_turn_kp = eePromReadFloat();
  regul_turn_ti = eePromReadFloat();
  regul_turn_td = eePromReadFloat();
  regul_turn_alpha = eePromReadFloat();
  regul_turn_i_limit = eePromReadFloat();
  regul_turn_step_time_on = eePromReadFloat();
  regul_turn_step_time_off = eePromReadFloat();
  regul_turn_step_val = eePromReadFloat();
  regul_turn_step_vel = eePromReadFloat();
  regul_acc_limit = eePromReadFloat();
  regul_turn_LeadFwd = eePromRead();
  // balance ctrl
  regul_bal_use = eePromRead();
  regul_bal_kp = eePromReadFloat();
  regul_bal_ti = eePromReadFloat();
  regul_bal_td = eePromReadFloat();
  regul_bal_alpha = eePromReadFloat();
  regul_bal_i_limit = eePromReadFloat();
  regul_bal_u_limit = eePromReadFloat();
  regul_balvel_step_time = eePromReadFloat();
  regul_balvel_step_from = eePromReadFloat();
  regul_balvel_step_to = eePromReadFloat();
  regul_balvel_use = eePromRead();
  regul_bal_LeadFwd = eePromRead();
  // balance velocity ctrl
  regul_balvel_kp = eePromReadFloat();
  regul_balvel_ti = eePromReadFloat();
  regul_balvel_td = eePromReadFloat();
  regul_balvel_zeta = eePromReadFloat();
  regul_balvel_alpha = eePromReadFloat();
  regul_balvel_i_limit = eePromReadFloat();
  regul_balvel_u_limit = eePromReadFloat();
  regul_balVel_LeadFwd = eePromRead();
  //
  initRegulators();
}
