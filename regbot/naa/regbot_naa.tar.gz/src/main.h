/***************************************************************************
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   Main function for small regulation control object (regbot)
 *   build on a small 72MHz ARM processor MK20DX256,
 *   intended for 31300 Linear control
 *   has an IMU and a dual motor controller with current feedback.
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef REGBOT_MAIN_H
#define REGBOT_MAIN_H

#include <string.h>
#include <stdlib.h>
#include <usb_serial.h>
#include <core_pins.h>
#include <HardwareSerial.h>

// control period is time between control calls
// and is in units of 10us, ie 125 is 1.25ms or 800Hz
#define CONTROL_PERIOD_10us 100
#define SAMPLETIME  (0.00001 * CONTROL_PERIOD_10us)

extern int robotId; // robot number [1..999]
extern volatile uint32_t hb10us;     /// heartbeat timer count (10 us)
extern volatile uint32_t hbTimerCnt;
extern bool missionStart; // start from Gui
extern bool missionStop;  // stop from Gui
extern float time; // mission time
extern bool button; // start switch
extern bool motorPreEnabled;
extern int usb_not_idle_cnt;
extern bool sendStatusWhileRunning;
// ADC setup
const bool useADCInterrupt = true;
const int useADCresolution = 12;
const float useADCMaxADCValue = 4096*2;
/**
 * is USB serial idle (tx buffer empty) */
inline bool usb_idle()
{ // virker ikke - rapporterer altid idle
  // også hvis USB ikke er forbundet
  if (serial_write_buffer_free() > 40) // 64 bytes in tx-buffer 
    return true;
  else
  {
    usb_not_idle_cnt++;
    return false;
  }
}


/**
 * Send string to USB channel */
inline void usb_send_str(const char * str)
{
  //if (usb_idle())
    // if no space, then do not send (usb serial is of low priority)
    usb_serial_write(str, strlen(str));
}

/**
 * Push value to ee-prom 
 * Must be called in the right sequence - write and read,
 * all values are cast to 32 bit values */
void eePromPush(uint32_t value);
// static inline void eePromPush(int value)
// {
//   eePromPush((uint32_t)value);
// }
inline void eePromPushFloat(float value)
{
  union {float f; uint32_t u32;} u;
  u.f = value;
  eePromPush(u.u32);
}

uint32_t eePromRead();
static inline float eePromReadFloat()
{
  union {float f; uint32_t u32;} u;
  u.u32 = eePromRead();
  return u.f;  
}


#endif