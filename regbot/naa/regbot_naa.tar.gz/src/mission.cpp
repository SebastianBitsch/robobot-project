/***************************************************************************
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   Main function for small regulation control object (regbot)
 *   build on a small 72MHz ARM processor MK20DX256,
 *   intended for 31300 Linear control
 *   has an IMU and a dual motor controller with current feedback.
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include <string.h>
#include <stdio.h>
#include "math.h"
#include "mission.h"
#include "serial_com.h"

UMission mLines[mLinesCntMax];
int mLinesCnt = 0;

char missionErrStr[missionErrStrMaxCnt];


void UMission::clear()
{
  accUse = false;
  logUse = false;
  trUse = false;
  velUse = false;
  balUse = false;
  //
  distUse = false;
  timeUse = false;
  turnUse = false;
  // 
  valid = false;
}


int UMission::toString(char* bf, int bfCnt, bool frame)
{
  char * ms = bf;
  char * mc;
  int n = 0;
  const char sep = ',';
  if (not valid)
  {
    strncpy(ms, "# not valid", bfCnt - n);
    n += strlen(ms);
    ms = &bf[n];
  }
  else if (frame)
  {
    strcpy(ms, "<m ");
    n+=3;
    ms = &bf[n];
  }
  if (velUse)
  {
    if (n > 3) {*ms++=sep; n++;}
    snprintf(ms, bfCnt - n, "vel=%g", vel);
    n += strlen(ms);
    ms = &bf[n];
  }
  if (accUse)
  {
    if (n > 3) {*ms++=sep; n++;}
    snprintf(ms, bfCnt - n, "acc=%g", acc);
    n += strlen(ms);
    ms = &bf[n];
  }
  if (trUse)
  {
    if (n > 3) {*ms++=sep; n++;}
    snprintf(ms, bfCnt - n - 1, "tr=%g", tr);
    n += strlen(ms);
    ms = &bf[n];
  }
  if (logUse)
  {
    if (n > 3) {*ms++=sep; n++;}
    snprintf(ms, bfCnt - n - 1, "log=%g", log);
    n += strlen(ms);
    ms = &bf[n];
  }
  if (balUse)
  {
    if (n > 3) {*ms++=sep; n++;}
    snprintf(ms, bfCnt - n - 1, "bal=%d", bal);
    n += strlen(ms);
    ms = &bf[n];
  }
  // not the condition part - if it exist
  mc = ms;
  *mc++ = ':';
  n++;
  if (distUse)
  {
    if (mc - ms > 1) {*mc++=sep; n++;}
    snprintf(mc, bfCnt - n - 1, "dist=%g", dist);
    n += strlen(mc);
    mc = &bf[n];
  }
  if (timeUse)
  {
    if (mc - ms > 1) {*mc++=sep; n++;}
    snprintf(mc, bfCnt - n - 1, "time=%g", time);
    n += strlen(mc);
    mc = &bf[n];
  }
  if (turnUse)
  {
    if (mc - ms > 1) {*mc++=sep; n++;}
    snprintf(mc, bfCnt - n - 1, "turn=%g", turn);
    n += strlen(mc);
    mc = &bf[n];
  }
  if (turnUse)
  {
    if (mc - ms > 1) {*mc++=sep; n++;}
    snprintf(mc, bfCnt - n - 1, "turn=%g", turn);
    n += strlen(mc);
    mc = &bf[n];
  }
  if (frame)
  {
    strncpy(mc, "\n\r", bfCnt - n - 1);
    n += strlen(mc);
  }
  return n;
}


bool UMission::decodeLine(const char* buffer)
{
  char * p1 = (char *)buffer;
  char * p2 = strchr(p1, ':');
  char * p3 = strchr(p1, '=');
  bool err = false;
  // reset use flags
  clear();
  // strip white space
  while (*p1 <= ' ' and *p1 > '\0') p1++;
  // find all parameters until ':'
  while ((p1 < p2 or p2 == NULL) and p3 != NULL)
  {
    if (strncmp (p1, "acc", 3) == 0)
    {
      accUse = true;
      acc = strtof(++p3, &p1);
    }
    else if (strncmp (p1, "vel", 3) == 0)
    {
      velUse = true;
      vel = strtof(++p3, &p1);
    }
    else if (strncmp (p1, "tr", 2) == 0)
    {
      trUse = true;
      tr = fabsf(strtof(++p3, &p1));
    }
    else if (strncmp (p1, "log", 3) == 0)
    {
      logUse = true;
      log = strtof(++p3, &p1);
    }
    else if (strncmp (p1, "bal", 3) == 0)
    {
      balUse = true;
      bal = strtof(++p3, &p1) > 0.5;
    }
    else
    { // error, just skip
      snprintf(missionErrStr, missionErrStrMaxCnt, "failed parameter at %s", p1);
      p1 = ++p3;
      err = true;
    }
    // remove white space
    while ((*p1 <= ' ' or *p1 == ',') and *p1 > '\0') p1++;
    p3 = strchr(p1, '=');
    
  }
  if (p2 != NULL)
  {
    p1 = p2 + 1;
    while (*p1 <= ' ' and *p1 > '\0') p1++;
    p3 = strchr(p1, '=');
    while (*p1 > '\0' and p3 != NULL)
    {
      if (strncmp (p1, "dist", 4) == 0)
      { // distance is always positive (even if reversing)
        distUse = true;
        dist = fabsf(strtof(++p3, &p1));
      }
      else if (strncmp (p1, "turn", 4) == 0)
      {
        turnUse = true;
        turn = strtof(++p3, &p1);
      }
      else if (strncmp (p1, "time", 4) == 0)
      {
        timeUse = true;
        time = strtof(++p3, &p1);
      }
      else
      { // error, just skip
        snprintf(missionErrStr, missionErrStrMaxCnt, "failed condition at %s", p1);
        p1 = ++p3;
        err = true;
      }
      // remove white space
      while ((*p1 <= ' ' or *p1 == ',') and *p1 > '\0') p1++;
      p3 = strchr(p1, '=');
    }
  }
  valid = not err;
  return err;
}
