/**
 * \file
 *
 * \brief Bosch Digital pressure sensor common definitions
 *
 * This module defines registers, constants, data structures, and
 * global function prototypes that are common to multiple Bosch sensor
 * drivers, in particular those for BMP085 and BMP180 devices.
 *
 * Copyright (c) 2012 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */
#ifndef _BMP_COMMON_H_
#define _BMP_COMMON_H_

//#include <asf.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief BMP085 & BMP180 calibration coeffs
 *
 * Every sensor module has unique individual coefficients stored in the device
 * EEPROM.  Before pressure and temperature can be calculated these values must
 * be read and stored for use in the compensated (i.e. "real") temperature and
 * pressure calculations.
 *
 * This data structure and macros below define a type that stores calibration
 * coefficients for Bosch BMP085, BMP180, or SMD500 pressure sensors.  The
 * fields are named per the Bosch documentation defining the compensated
 * temperature and pressure equations that require these coefficients.
 *
 * The driver currently statically allocates storage for only one copy of
 * the calibration coefficients.  In the event that a system is built with
 * multiple BMP085 (for example) pressure sensors this scheme will not work,
 * as each physical device will require a device-specific copy of the coeffs
 * for use in compensated temperature and pressure calculations for the device.
 */
typedef struct 
{
  int16_t ac1;
  int16_t ac2;
  int16_t ac3;
  uint16_t ac4;
  uint16_t ac5;
  uint16_t ac6;

  int16_t b1;
  int16_t b2;

  int16_t mb;
  int16_t mc;
  int16_t md;
  // measurements
  int tempRaw;
  int tempC;  // temperature in 0.1 degrees Celsius
  int presRaw;
  int presPascal;  // pressure in Pa
  float height;    // height in meters
  // measurement count
  int measCnt;
  // reference presure at height zero
  float presP0;
  //
  int useBaro;
  int filtFac;
  // private
  int32_t b3, b4, b5, b6, b7, xt1, xt2, x1a, x1b, x1c, x1d, x2a, x2b, x2c, x3a, x3b;
} bmp_data_t;

/** \brief  BMP "oversampling_setting" mode values */
typedef enum {
  OSS_LOW_POWER  = 0, /**< Ultra low power       (1 internal samples) */
  OSS_STANDARD   = 1, /**< Standard              (2 internal samples) */
  OSS_HIGH       = 2, /**< High resolution       (4 internal samples) */
  OSS_ULTRA_HIGH = 3  /**< Ultra high resolution (8 internal samples) */
} osrs_t;

extern osrs_t baro180_oss;
extern bmp_data_t baro180data;

#define BMP_RESOLUTION  (24 - (8 - sensor_oss))

#define AC1     (baro180data.ac1)
#define AC2     (baro180data.ac2)
#define AC3     (baro180data.ac3)
#define AC4     (baro180data.ac4)
#define AC5     (baro180data.ac5)
#define AC6     (baro180data.ac6)
#define BB1      (baro180data.b1)
#define BB2      (baro180data.b2)
#define BMB      (baro180data.mb)
#define BMC      (baro180data.mc)
#define BMD      (baro180data.md)

  
/* TWI/I2C address (write @ 0xee on bus, read @ 0xef on bus) */
#define BMP_TWI_ADDR               (0x77)

/** \brief BMP Register Addresses */
/** @{ */
#define BMP_CHIP_ID                (0xd0)   /* chip ID - always 0x55 */
#define BMP_CHIP_VERSION           (0xd1)   /* chip revision */
#define BMP_SOFT_RESET             (0xe0)   /* reset device */
#define BMP_CONTROL                (0xf4)   /* device control register */
#define BMP_DATA_MSB               (0xf6)   /* temp. or press. data MSB */
#define BMP_DATA_LSB               (0xf7)   /* temp. or press. data LSB */
#define BMP_DATA_XLSB              (0xf8)   /* press. data XLSB (19 bit data) */
/** @} */

/* EEPROM Calibration Coefficient Addresses (MSB | LSB) */

#define BMP_EEPROM_ADDR            (0xaa)   /* BMP085/BMP180 EEPROM base address */
#define BMP_EEPROM_SIZE_BYTES      (22)     /* BMP085/BMP180 EEPROM size (bytes) */

/** \brief BMP Register Bit Definitions */
/** @{ */

/* BMP_CHIP_ID (0xd0) */

// #define BMP085_ID_VAL              (0x55)   /* BMP085 chip id value */
// #define BMP085_VER_VAL             (0x01)   /* BMP085 chip version value */

#define BMP180_ID_VAL              (0x55)   /* BMP180 chip id value */
#define BMP180_VER_VAL             (0x02)   /* BMP180 chip version value */

/* BMP_SOFT_RESET (0xe0) */

#define BMP_RESET_CMD              (0xb6)   /* soft reset command */

/* BMP_CONTROL (0xf4) */

#define BMP_TEMP_READ              (0x2e)   /* read temperature */
#define BMP_PRESS_READ             (0x34)   /* read pressure (@ osrs = 0) */

/* Operating Ranges */

#define BMP_MIN_hPa                (300)    /* +9 000 (m) above sea level */
#define BMP_MAX_hPa                (1100)   /* -500 (m) above sea level */

#define BMP_MIN_COUNTS             (0)
#define BMP_MAX_COUNTS             (0xfffful)

/** @} */

//extern bool bmp085_init(sensor_t *, int);
/**
 * Convert temperature and pressure value to compensated pressure 
 * using the raw temperature and pressurevalues in the baro180data structure
 * and saves the result - temperature and pressure in thesame structure. */
extern void bmp180_calculatePressure();
/**
 * @brief Get a temperature sensor sample.
 *
 * If scaled data format is selected for the device, this routine gets a
 * compensated "true temperature" sample.  Otherwise, a raw uncompensated
 * temperature reading is returned in "data".
 *
 * @param sensor    Address of an initialized sensor device descriptor.
 * @param data      The address where temperature samples are returned.
 * @return temperature in 0.1 degree C units 
 */
extern int bmp_get_temperature(int UT);

#ifdef __cplusplus
}
#endif

#endif
