/***************************************************************************
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   Main function for small regulation control object (regbot)
 *   build on a small 72MHz ARM processor MK20DX256,
 *   intended for 31300 Linear control
 *   has an IMU and a dual motor controller with current feedback.
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifndef REGBOT_MISSION_H
#define REGBOT_MISSION_H

#include <string.h>
#include <stdlib.h>

class UMission
{
public:
  float vel;
  bool velUse;
  float acc;
  bool accUse;
  float log;
  bool logUse;
  bool bal;
  bool balUse;
  float tr;
  bool trUse;
  float dist;
  bool distUse;
  float turn;
  bool turnUse;
  float time;
  bool timeUse;
public:
  bool valid;
  
public:
  /** clear all valid flags */
  void clear();
  /** convert to string - for return message 
   * \param bf is a C char array 
   * \param bfCnt is the count of bytes in bf
   * \returns buffer (bf) filled from class and the used number of bytes */
  int toString(char * bf, int bfCnt, bool frame = true);
  /** decode mission line 
   * \param buffer is expected to hold a mission line in a terminated C string
   * \returns true if loaded with no errors */
  bool decodeLine(const char * buffer);
};

const int mLinesCntMax = 50;
extern UMission mLines[mLinesCntMax];
extern int mLinesCnt;

const int missionErrStrMaxCnt = 50;
extern char missionErrStr[missionErrStrMaxCnt];

#endif