/***************************************************************************
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   Main function for small regulation control object (regbot)
 *   build on a small 72MHz ARM processor MK20DX256,
 *   intended for 31300 Linear control
 *   has an IMU and a dual motor controller with current feedback.
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#define REV_MAIN 2
#define REV "$Rev: 136 $"
#define REV_MINOR 11

#define REV_ID "$Id: main.cpp 136 2015-09-21 19:17:48Z jcan $" 

#include <malloc.h>
#include "IntervalTimer.h"
#include "mpu9150.h"
#include "motor_controller.h"
#include "serial_com.h"
#include "data_logger.h"
#include "../control.h"
#include "baro180.h"
#include "robot.h"
#include "main.h"
#include "mission.h"
//#include <ADC.h>
//#include <DMAChannel.h>
#include <ADC.h>
//#define __MK20DX256__

int robotId = 0;
/** main heartbeat timer to service source data and control loop interval */
IntervalTimer hbTimer;
float time = 0.0; // system time in seconds
uint32_t timeAtMissionStart = 0;
const char * lfcr = "\n\r";
bool pushToUSB = 1;
//bool logToSD = 0;  // no SD-card anymore
bool logToUSB = 0;
// reply from ardulog send back to usb connection
bool loggerReplyToUSB = false;
// should teensy echo commands to usb
uint8_t localEcho = 0;
// stop sending status to usb after this count
int pushCnt = 30;
// read from magnetometer every this magCntMax
int magCnt = 5, magCntMax = 100;
// read from acc/gyro every this accCntMax
int accCnt = 0, accCntMax = 1;
// read motor feedback current every this currentCntMax
int currentCnt = 1, currentCntMax = 1;
// read battery voltage every this batMaxCnt
int batVoltCnt = 2, batVoltCntMax = 5;
uint16_t batVoltInt = 0;
// flag reset at when motor is enabled first time
bool motorPreEnabled = 1;
uint32_t motorCurrentMLowPass[2];
//
// heart beat timer
volatile uint32_t hbTimerCnt = 0; /// heart beat timer count (control_period)
volatile uint32_t hb10us = 0;     /// heart beat timer count (10 us)
// flag for start of new control period
volatile bool startNewCycle = false;
uint16_t controlUsedTime[2] = {0,0};
int pushInterval = 0;
int pushTimeLast = 0;
int pushStatus = 0;

//
// EEprom adress - max 2kb (512 words)
uint32_t eePushAdr = 0;
/**
 * Get SVN revision number */
uint16_t getRevisionNumber()
{
  return strtol(&REV[5], NULL, 10) * 100 + REV_MINOR;
}

// mission stop and start
bool button;
bool missionStart = false;
bool missionStop = false;
bool sendStatusWhileRunning = false;
/**
 * usb command buffer space */
#define RX_BUF_SIZE 110
char usbRxBuf[RX_BUF_SIZE];
int usbRxBufCnt = 0;
int usb_not_idle_cnt = 0;

/**
 * Heart beat interrupt service routine */
void hbIsr(void);
/**
 * write to I2C sensor (IMU) */
int writeSensor(uint8_t i2caddr, int reg, int data);
/**
 * Parse commands from the USB connection and implement those commands.
 * The function is served by the main loop, when time allows. */
void parse_and_execute_command(const char *buf, uint8_t num);
/**
 * log state to ram-buffer
 * - stops when no more space */
void stateToLog();
/**
 * send state as text to USB (direct readable) */
void stateToUsb();
/**
 * initialize barometer by reading calibration values */
bool baro180_init();
/**
 * Start temperature measurement,
 * returns 0 if successfull */
int baro180_startTempMeasurement();
/**
 * Start pressure measurement,
 * returns 0 if successfull */
int baro180_startPressureMeasurement();
/**
 * is measurement finished
 * returns 1 if finished, 0 if not and -1 if com error */
int baro180_isMeasurementFinished();
/**
 * read result - either temp or pressure - as 16 bit unsigned int */
int baro180_readResult();
/**
 * read result - pressure - as 19 bit unsigned int adjusted with oversampling value */
int baro180_readResultP3();
/// send push status
void sendStatusSensor();
void sendStatusLogging();
void eePromSaveStatus();
void eePromLoadStatus();


typedef enum {BARO_TEMP_START, BARO_TEMP_WAIT, BARO_PRES_WAIT} UBaroMeasState;
UBaroMeasState baroMeasState = BARO_TEMP_START;

ADC * adc = new ADC();
// const bool useADCInterrupt = true;
uint16_t adcLSH[8] = {0,1,2,3,4,5,6,7};
uint16_t adcLSL[8] = {0,1,2,3,4,5,6,7};
uint16_t adcInt0Cnt = 0;
uint16_t adcInt1Cnt = 0;
uint16_t adcStartCnt = 0, adcHalfCnt = 0;
const int MAX_ADC = 11;
const int LS_FIRST = 3;
uint16_t * adcDest[LS_FIRST] = {&batVoltInt, &motorCurrentM[0], &motorCurrentM[1]};
int adcPin[MAX_ADC] = {9, 10, 11, 12, 13, 15, 16, 17, 9, 9, 9};
int adcSeq = 0;
bool adcHalf; // for double ADC conversion for LS
uint32_t adcStartTime, adcConvertTime;
uint32_t adcHalfStartTime, adcHalfConvertTime;
///

int readAccGyro();
/**
 * Request a number of data from an i2c client
 * the data is in the Wire (or Wire1) buffer and read by Wire.read() called
 * \param i2caddr is the 7-bit address of the device ox68 for imu or 0x0c for readMagnetometer
 * \param reg is register number to read from
 * \param readCnt is number of registers to read
 * \returns number of characters available in read buffer */
int readToBuffer(uint8_t i2cAddr, uint8_t reg, uint8_t readCnt)
{ //
  int a;
  //
  Wire.beginTransmission(i2cAddr);
  Wire.write(reg);
  a = Wire.endTransmission(I2C_NOSTOP,1000);
  a = Wire.requestFrom(i2cAddr, readCnt, I2C_STOP, 1000);
  return a;
}

//////////////////////////////////////////////////////////

void readMagnetometer()
{ // must be read by the MPU9150 first, by setting up a set of registers
  // and then reading the buffer registers in MPU9150
  // - some may be set up in initializeer of MPU9150
#define IMU_REG_MAG 00
#define IMU_MAG_I2C_ADDR 0x0C
  int a;
  bool debug = false;
  // test for data available
  a = readToBuffer(IMU_MAG_I2C_ADDR, 2, 1);
  if (a > 0 and (Wire.read() == 1))
  {
    int h, l, r;
    int magID = 7, magInfo = 7, magSt1 = 7, magst2 = 7;
    //

  //   Wire.beginTransmission(IMU_MAG_I2C_ADDR);
  //   Wire.write(IMU_REG_MAG);
  //   ak = Wire.endTransmission(I2C_NOSTOP,1000);
  //   a = Wire.requestFrom(IMU_MAG_I2C_ADDR, 10, I2C_STOP, 1000);
    a = readToBuffer(IMU_MAG_I2C_ADDR, 0, 10);
    r = 0;
    if (a > 2)
    { // data package is available - save data
      magID = Wire.read();
      magInfo = Wire.read();
      magSt1 = Wire.read();
      for (int i = 0; i < 3; i++)
      {
        l = Wire.read();
        h = Wire.read();
        if (h >= 0 and l >= 0)
        {
          imuMag[i] =(h << 8) + l;
          r++;
        }
      }
      magst2 = Wire.read();
    }
    if (debug)
    {
      const int MRL = 100;
      char reply[MRL];
      snprintf(reply, MRL, "mag got %d id %x info %x st1 %x mag %7d %7d %7d st2 %x",
        a, magID, magInfo, magSt1, imuMag[0], imuMag[1], imuMag[2], magst2
      );
      usb_send_str(reply);
    }
    // magnetometer single measurement mode (again)
    writeSensor(IMU_MAG_I2C_ADDR, 0x0A, 0x01);
  }
}

////////////////////////////////////////////

void sendStatusMag()
{
  const int MRL = 250;
  char reply[MRL];
  snprintf(reply, MRL, "mag %d %d %d\r\n",
           imuMag[0], imuMag[1], imuMag[2]);
  usb_send_str(reply);
}

////////////////////////////////////////////

void sendStatusLS()
{
  const int MRL = 250;
  char reply[MRL];
  //                       #1 #2   LS0    LS1    LS2    LS3    LS4    LS5    LS6    LS7    timing (us)
  snprintf(reply, MRL, "ls %d %d  %d %d  %d %d  %d %d  %d %d  %d %d  %d %d  %d %d  %d %d  %ld %ld\r\n",
           adcStartCnt, adcHalfCnt, 
           adcLSH[0], adcLSL[0], adcLSH[1], adcLSL[1], adcLSH[2], adcLSL[2], adcLSH[3], adcLSL[3], 
           adcLSH[4], adcLSL[4], adcLSH[5], adcLSL[5], adcLSH[6], adcLSL[6], adcLSH[7], adcLSL[7], 
           adcConvertTime * 10, adcHalfConvertTime * 10);
  usb_send_str(reply);
}

////////////////////////////////////////////

void sendStatusCurrentVolt()
{
  const int MRL = 250;
  char reply[MRL];
  snprintf(reply, MRL, "VA %d %.3f  %d %d %.3f  %d %d %.3f\r\n",
           batVoltInt, batVoltFloat, 
           motorCurrentM[0], motorCurrentMOffset[0], getMotorCurrentM(0, motorCurrentM[0]),
           motorCurrentM[1], motorCurrentMOffset[1], getMotorCurrentM(1, motorCurrentM[1])
          );
  usb_send_str(reply);
}

//////////////////////////////////////////////////////

/**
 * Test all I2C adresses and print reply. */
void testAddr(void)
{
  int ak;
  const int MRL = 100;
  char reply[MRL];
  for (int i= 0; i < 0x7f; i++)
  {
    Wire.beginTransmission(i);
    Wire.write(0);
    ak = Wire.endTransmission(I2C_STOP,1000);
    snprintf(reply, MRL, "addr test addr %d (%x) gave %d", i, i, ak);
    usb_send_str(reply);
  }
}

//////////////////////////////////////////

/**
 * write one byte to a sensor (i2c) register
 * \param addr is i2c 7-bit address
 * \param reg is (8-bit) register to write to
 * \param data is 8-bit data to write
 * \returns 0 in succes and 1, 2, 3, 4 on error */
int writeSensor(uint8_t i2caddr, int reg, int data)
{
  // pack buffer
  Wire.beginTransmission(i2caddr);
  Wire.write(reg);
  Wire.write(data);
  // send package
  return Wire.endTransmission(I2C_STOP); // send the data
}


void initialization()
{ // INITIALIZATION
  pinMode(LED_BUILTIN, OUTPUT);
  // init USB connection (parameter is not used - always 12MB/s
  Serial.begin(115200); 
  // init serial to ardulog
  Serial1.begin(115200);    // Ardulog does - for some reason - not function at baud rate beyond 9600.
  // init IMU
  delay(100);             // Required for MPU to get out of sleep mode after restart
  // I2C init
  // Setup for Master mode, pins 18/19, external pullups, 400kHz
  Wire.begin(I2C_MASTER, 0x00, I2C_PINS_16_17, I2C_PULLUP_EXT, I2C_RATE_400);
  // Initialization of MPU9150
  MPU9150_init();
  writeSensor(IMU_MAG_I2C_ADDR, 0x0A, 0x01);
  // baro180_init
//   if (true)
//     baro180_init();
  // init motor control
  motorInit();           // init ports PWM out, direction out, encoder in
  // init AD converter
  if (useADCInterrupt)
  { // AD using interrupt
    adc->adc0->setReference(ADC_REF_1V2);
    adc->adc1->setReference(ADC_REF_1V2);
    // not needed
    adc->adc0->recalibrate();
    adc->adc1->recalibrate();
    adc->setResolution(12, 0);
    adc->setResolution(12, 1);
    adc->setConversionSpeed(ADC_MED_SPEED, 0);
    adc->setConversionSpeed(ADC_MED_SPEED, 1);
  }
  else
  { // AD poll
    analogReference(INTERNAL);
  }
  // more pins
  pinMode(23,INPUT); // battery voltage
  pinMode(11,INPUT); // start switch
  pinMode(18,OUTPUT); // IMU finished interrupt
  // start 10us timer (heartbeat timer)
  hbTimer.begin(hbIsr, (unsigned int)  10); // heartbeat timer, value in usec
  //
  // data logger init
  // data log size and count must be initialized here
  // there must further be a write function and other parts in data_logger.cpp 
  // to add new logged data items
  setLogSize(LOG_TIME, 1, LOG_FLOAT);
  setLogSize(LOG_MISSION, 1, LOG_INT16);
  setLogSize(LOG_ACC,  3, LOG_INT16);
  setLogSize(LOG_GYRO, 3, LOG_INT16);
  setLogSize(LOG_MAG,  3, LOG_INT16);
  setLogSize(LOG_MOTV_REF, 2, LOG_FLOAT);
  setLogSize(LOG_MOTV, 2, LOG_INT16);
  setLogSize(LOG_MOTA, 4, LOG_INT16);
  setLogSize(LOG_ENC,  2, LOG_UINT32);
  setLogSize(LOG_POSE, 4, LOG_FLOAT);
  setLogSize(LOG_WHEELVEL,  2, LOG_FLOAT);
  setLogSize(LOG_TURNRATE,  1, LOG_FLOAT);
  setLogSize(LOG_BATT, 1, LOG_UINT16);
  setLogSize(LOG_CTRLTIME, 2, LOG_INT16);
  //setLogSize(LOG_BARO, 4, LOG_INT16);
  setLogSize(LOG_BAL_CTRL, 5, LOG_FLOAT);
  setLogSize(LOG_EXTRA, 4, LOG_FLOAT);
  logRowFlags[LOG_TIME] = 1; // not tested - time always on
  //
  setLogFlagDefault();
  initLogStructure(100000 / CONTROL_PERIOD_10us);
  // init encoder interrupts
  attachInterrupt(M1ENC_A, m1EncoderA, CHANGE);
  attachInterrupt(M2ENC_A, m2EncoderA, CHANGE);
  attachInterrupt(M1ENC_B, m1EncoderB, CHANGE);
  attachInterrupt(M2ENC_B, m2EncoderB, CHANGE);
  //
  // read configuration from EE-prom (if ever saved)
  // this overwrites the just set configuration for e.g. logger
  eePromLoadStatus();
}

//////////////////////////////////////////////////////////

/**
 * Got a new character from USB channel
 * Put it into buffer, and if a full line, then intrepid the result.
 * \param n is the new character */
void receivedCharFromUSB(uint8_t n)
{ // got another character from usb host (command)
  if (n >= ' ')
  {
    usbRxBuf[usbRxBufCnt] = n;
    if (usbRxBufCnt < RX_BUF_SIZE - 1)
      usbRxBuf[++usbRxBufCnt] = '\0';
  }
  if (localEcho)
    // echo characters back to terminal
    usb_serial_putchar(n);
  if ((n == '\n' or n=='\r') and usbRxBufCnt > 0)
  {
    parse_and_execute_command(usbRxBuf, usbRxBufCnt);
    if (localEcho)
    {
      usb_send_str("\r\n>>");
      //usb_serial_flush_output();
    }
    // flush remaining input
    // usb_serial_flush_input();
    usbRxBufCnt = 0;
  }
  else if (usbRxBufCnt >= RX_BUF_SIZE - 1)
  { // garbage in buffer, just discard
    usbRxBuf[usbRxBufCnt] = 0;
    const char * msg = "** Discarded (missing \\n)\n";
    usb_send_str(msg);
    usbRxBufCnt = 0;
  }
}

/**
 * Read data from sensors, if time to do so 
 * \returns true if IMU could be read */
void readSensors()
{
//   #define AnalogA0 15 // motor 1 (left)
//   #define AnalogA1 14 // motor 2
  if (useADCInterrupt)
  { // start first AC conversion
    adcSeq = 0;
    adcHalf = false;
    adc->startSingleRead(adcPin[0]);
    adcStartTime = hb10us;
    adcStartCnt++;
  }
  // read start button
  button = digitalRead(11);
  //
  if (--accCnt <= 0)
  { // read from IMU
    readAccGyro();
    accCnt = accCntMax; 
  }
//   if ((magCntMax > 0) and (--magCnt <= 0))
//   { // read from compas
//     readMagnetometer();
//     magCnt = magCntMax;
//   }
  //
  // start read of analogue values
  if (useADCInterrupt)
  { // convert last value to float
    // measured over a 15kOhm and 1.2kOhm divider with 1.2V reference
    batVoltFloat = batVoltInt * 1.2 / useADCMaxADCValue * (15.0 + 1.2)/1.2;
    //
    if (motorPreEnabled)
    { // low pass input values (using long integer) - about 100ms time constant (if currentCntMax==1)
      // running until first motor is enabled
      motorCurrentMLowPass[0] = (motorCurrentMLowPass[0] * 199)/200 + motorCurrentM[0];
      motorCurrentMLowPass[1] = (motorCurrentMLowPass[1] * 199)/200 + motorCurrentM[1];
      // save as direct usable value
      motorCurrentMOffset[0] = motorCurrentMLowPass[0] / 200;
      motorCurrentMOffset[1] = motorCurrentMLowPass[1] / 200;
    }
    motorCurrentA[0] = getMotorCurrentM(0, motorCurrentM[0]);
    motorCurrentA[1] = getMotorCurrentM(1, motorCurrentM[1]);
  }
  else
  {
    if (--currentCnt <= 0)
    { // time to read motor current
      motorCurrentM[0] = analogRead(10); // pin A10 and A11
      motorCurrentM[1] = analogRead(11);
      if (motorPreEnabled)
      { // low pass input values (using long integer) - about 100ms time constant (if currentCntMax==1)
        motorCurrentMLowPass[0] = (motorCurrentMLowPass[0] * 99)/100 + motorCurrentM[0];
        motorCurrentMLowPass[1] = (motorCurrentMLowPass[1] * 99)/100 + motorCurrentM[1];
        // save as direct usable value
        motorCurrentMOffset[0] = motorCurrentMLowPass[0] / 100;
        motorCurrentMOffset[1] = motorCurrentMLowPass[1] / 100;
      }
      currentCnt = currentCntMax;
    }
  }
  if (--batVoltCnt <= 0)
  { // read voltage from pin 23 - scaled by 15k over 3.6k and Vref=3.3
    if (not useADCInterrupt)
    {
//       for (int a = 0; a < 8; a++)
//       { // try to make 16 A/D every 5th ms
//         // approx 12 us per AD
//         batVoltInt = analogRead(a);
//         batVoltInt = analogRead(a + 10);
//       }
      batVoltInt = analogRead(23);
      batVoltFloat = batVoltInt * 1.2 / 1024 * (15.0 + 1.2)/1.2;
      batVoltCnt = batVoltCntMax;
    }
  }
}


int * m1;
/**
 * Main loop
 * primarily for initialization,
 * non-real time services and
 * synchronisation with heartbeat.*/
extern "C" int main(void)
{
  uint8_t n, m = 0;
  uint32_t loop = 0;
  int ltc, lastTimerCnt = 0; /// heartbeat timer loopcoun
  uint32_t loggerRowWait = 0;
  int row = 0;
  uint32_t start10us;
  //
  m1 = (int*)malloc(4);
  initialization();
  n = 0;
  readAccGyro();
  readMagnetometer();
  // feedback value from motor controller
//   motorCurrent[0] = analogRead(AnalogA0);
//   motorCurrent[1] = analogRead(AnalogA1);
  // from current-sensor
  if (useADCInterrupt)
  { // initialize analogue values
    motorCurrentM[0] = adc->analogRead(10);
    motorCurrentM[1] = adc->analogRead(11);
    batVoltInt = adc->analogRead(23);
    // initialize low-pass filter for current offset
    motorCurrentMLowPass[0] = adc->analogRead(10) * 100;
    motorCurrentMLowPass[1] = adc->analogRead(11) * 100;
    // enable interrupt for the remaining ADC oprations
    adc->enableInterrupts(0);
    adc->enableInterrupts(1);
  }
  else
  {
    motorCurrentM[0] = analogRead(10);
    motorCurrentM[1] = analogRead(11);
    // battery voltage
    batVoltInt = analogRead(23);
    // initialize low-pass filter for current offset
    motorCurrentMLowPass[0] = analogRead(10) * 100;
    motorCurrentMLowPass[1] = analogRead(11) * 100;
  }
  motorAnkerVoltage[0] = 0.0;
  motorAnkerVoltage[1] = 0.0;
  // addMotorVoltage(0, 0);
  motorSetAnchorVoltage();
  // turn on linesensor diodes
  digitalWriteFast(18, HIGH);
  // time starts now (in seconds)
  time = 0.0;
  // then just listen for commands and process them
  while (1)
  { // main loop
    // get data from usb - if available
    n = usb_serial_getchar();
    if (n >= '\n' && n < 0xfe)
    { // command arriving from USB
      receivedCharFromUSB(n);
    }
    //
    ltc = hbTimerCnt;
    if (startNewCycle)
    { // start of new control cycle
      startNewCycle = false;
      start10us = hb10us;      
      // read new sensor values
      readSensors();
      // record read sensor time
      controlUsedTime[0] = hb10us - start10us;
      // calculate sensor-related values
      updatePose(loop);
      estimateTilt();
      //
      if (missionState == 0)
      {  // we are waiting to start, so time since start is zero
        timeAtMissionStart = hb10us;
        if (time > 18000.0)
          // restart time (after 5 hours) - max usable time is 32768, as added in 1ms bits
          time = 0.0;
        // and allow manual setting of anchor voltage
      }
      // do control
      controlTick();
      // implement the new controlled motor voltage
//       if ((motorAnkerVoltage[0] != 0.0 or motorAnkerVoltage[1] != 0.0) and (loop % 200 == 0))
//       {
//         const int MSL = 50;
//         char s[MSL];
//         snprintf(s, MSL, "# main motor volt %g %g\r\n", motorAnkerVoltage[0], motorAnkerVoltage[1]);
//         usb_send_str(s);
//       }
      motorSetAnchorVoltage();
      //
      if (missionStart)
      {
        // usb_send_str("#** mission started\n");
        missionStart = false;
      }
      if (missionStop)
      { usb_send_str("#** mission stopped\n");
        missionStop = false;
      }
      //
      // record read sensor time + control time
      controlUsedTime[1] = hb10us - start10us;
    }
    //
    if ((pushInterval > 0) && (ltc - pushTimeLast) >= pushInterval)
    {
      pushTimeLast = ltc;
      if ((missionState == 0 or sendStatusWhileRunning) and gyroOffsetDone)
      { // not in a mission, so
        // send status
        switch(pushStatus++)
        {
          case 0 : 
          case 2 : 
          case 4 :
          case 6:
            sendStatusSensor(); 
            break;
          case 1 : 
            sendStatusControl();
            break;
          case 3 : 
            sendStatusMission(); 
            break;
          case 5 : 
            sendStatusLogging(); 
            break;
          case 7 : 
            sendStatusRobotID(); 
            break;
//           case 8:
//             snprintf(s, MSL, "# Main 3 areana %d (%d %d)\n", mallinfo().arena, malloc_info());
//             usb_send_str(s);
//             break;
          default:
            pushStatus = 0;
        }
      }
      else if (not gyroOffsetDone and hbTimerCnt % 1000 == 0)
      {
        usb_send_str("# IMU: gyro not calibrated\n");
      }
    }
    if ((ltc - lastTimerCnt) >= logInterval)
    {
      lastTimerCnt = ltc;
      m++;
      if (pushToUSB)
        stateToUsb();
      if (loggerLogging())
      {
        digitalWriteFast(LED_BUILTIN,(m & 0xff) < 128);
        stateToLog();
      }
      else if (logToUSB and (hbTimerCnt - loggerRowWait) > 10)
      { // attempt to wait a bit after a few lines send to logger
        // but do not seem to work, so set to just 10ms wait after 8 rows
        int row20 = 0;
        // signal log read using on-board LED
        digitalWriteFast(LED_BUILTIN,HIGH);
        // transfer 8 rows at a time
        for (row20 = 0; row < logRowCnt and row20 < 8; row20++)
        { // write buffer log to destination
          row = logWriteBufferTo(row);
          row++;
        }
        // set pause time
        loggerRowWait = hbTimerCnt;
        if (row >= logRowCnt)
        { // finished
          logToUSB = false;
          row = 0;
        }
        digitalWriteFast(LED_BUILTIN,LOW);
      }
    }
    loop++;
    if (loggerLogging())
      digitalWriteFast(LED_BUILTIN,(ltc & 0xff) < 127);
    else
      digitalWriteFast(LED_BUILTIN,(ltc & 0x3ff) < 10);
//     if (loop % (256*16) == 0)
//       digitalWriteFast(LED_BUILTIN,HIGH);
//     else
//       digitalWriteFast(LED_BUILTIN,LOW);
  }
  return 0;
}

/**
 * Heartbeat interrupt routine
 * schedules data collection and control loop timing.
 * */
void hbIsr(void)
{ // called every 10 microsecond
  // as basis for all timing
  hb10us++;
  if (hb10us % CONTROL_PERIOD_10us  == 0)
  {
    time += 1e-5 * CONTROL_PERIOD_10us; 
    hbTimerCnt++;
    startNewCycle = true;
    //
    // overload for encoder speed based on period
    if (not encTimeOverload[0])
      if ((int32_t)hb10us - (int32_t)encStartTime[0] > 256*8*256)
        encTimeOverload[0] = true;
    if (not encTimeOverload[1])
      if ((int32_t)hb10us - (int32_t)encStartTime[1] > 256*8*256)
        encTimeOverload[1] = true;
  } 
  if (hb10us % CONTROL_PERIOD_10us  == 60)
  { // start half-time ad conversion
    if (adcSeq >= MAX_ADC)
    {
      adcHalfStartTime = hb10us;
      adcSeq = 0;
      adc->startSingleRead(adcPin[0], -1);
      adcHalf = true;
      adcHalfCnt++;
    }
  }
}

// If you enable interrupts make sure to call readSingle() to clear the interrupt.
void adc0_isr() 
{
  uint16_t v = adc->adc0->readSingle();
  if (adcSeq < LS_FIRST)
    *adcDest[adcSeq] = ((*adcDest[adcSeq]) >> 1) + v;
  else if (adcHalf)
    adcLSH[adcSeq - LS_FIRST] = v;
  else
    adcLSL[adcSeq - LS_FIRST] = v;
  adcSeq++;
  if (adcSeq < MAX_ADC)
  { // start new and re-enable interrupt
    adc->startSingleRead(adcPin[adcSeq], -1);
  }
  else
  { // finished
    if (adcHalf)
    {
      adcHalfConvertTime = hb10us - adcHalfStartTime;
      digitalWriteFast(18, HIGH);
    }
    else
    {
      adcConvertTime = hb10us - adcStartTime;
      digitalWriteFast(18, LOW);
    }
  }
  adcInt0Cnt++;
}

//#if defined(ADC_TEENSY_3_1)
void adc1_isr() 
{
  uint16_t v = adc->adc1->readSingle();
  if (adcSeq < LS_FIRST)
    *adcDest[adcSeq] = ((*adcDest[adcSeq]) >> 1) + v;
  else if (adcHalf)
    adcLSH[adcSeq - LS_FIRST] = v;
  else
    adcLSL[adcSeq - LS_FIRST] = v;
  adcSeq++;
  if (adcSeq < MAX_ADC)
  { // start new and re-enable interrupt
    adc->startSingleRead(adcPin[adcSeq], -1);
  }
  else
  { // finished
    if (adcHalf)
    {
      adcHalfConvertTime = hb10us - adcHalfStartTime;
      digitalWriteFast(18, HIGH);
    }
    else
    {
      adcConvertTime = hb10us - adcStartTime;
      digitalWriteFast(18, LOW);
    }
  }
  adcInt1Cnt++;
}
//#endif

void sendStatusSensor()
{
  int switch2 = digitalRead(11);
  const int MRL = 350;
  char reply[MRL];
//   float mc0 = getMotorCurrent(0);
//   float mc1 = getMotorCurrent(1);
  snprintf(reply, MRL,  "hbt %f\n"
                        "acw %f %f %f\n"
                        "gyw %f %f %f\n"
                        "gyo %f %f %f %d\n"
                        "mca %f %f\n" //%d %d %d %d %ld %ld %f %f\n"
                        "enc 0x%lx 0x%lx\n"
                        "wve %f %f\n"
                        "wpo %f %f\n"
                        "pse %f %f %f %f %f\n"
                        "swv %d\n"
                        "bat %f\r\n" ,
          time,
          imuAcc[0] * accScaleFac, imuAcc[1] * accScaleFac, imuAcc[2] * accScaleFac,
          imuGyro[0] * gyroScaleFac, imuGyro[1] * gyroScaleFac, imuGyro[2] * gyroScaleFac,
           offsetGyro[0] * gyroScaleFac, offsetGyro[1] * gyroScaleFac, offsetGyro[2]* gyroScaleFac, gyroOffsetDone,
//            mc0, mc1, motorCurrentM[0], motorCurrentM[1], 
//            motorCurrentMOffset[0], motorCurrentMOffset[1],
//           motorCurrentMLowPass[0], motorCurrentMLowPass[1],
           getMotorCurrentM(0, motorCurrentM[0]), getMotorCurrentM(1, motorCurrentM[1]),
          encoder[0], encoder[1], 
          wheelVelocity[0], wheelVelocity[1],
          wheelPosition[0], wheelPosition[1],
          pose[0], pose[1], pose[2], distance, pose[3],
          switch2, 
          batVoltFloat
  );
  usb_send_str(reply);
}

void sendStatusLogging()
{
  const int MRL = 175;
  char reply[MRL];
  snprintf(reply, MRL, "lms %d\n"
                       "lac %d\n"
                       "lgy %d\n"
                       "lma %d\n"
                       "lvr %d\n"
                       "lmv %d\n"
                       "lma %d\n"
                       "lmr %d\n"
                       "ltr %d\n"
                       "lme %d\n"
                       "lpo %d\n"
                       "lbt %d\n"
                       "lbc %d\n"
                       "lex %d\n"
                       "lin %d\n"
                       "lct %d\n"
                       "lcn %d %d\r\n",
           logRowFlags[LOG_MISSION], // state number in mission
          logRowFlags[LOG_ACC],    // in ?
          logRowFlags[LOG_GYRO],   // in ?
          logRowFlags[LOG_MAG],    // not used
           logRowFlags[LOG_MOTV_REF],   // motor controller reference
           logRowFlags[LOG_MOTV],   // orderd anchor voltage before PWM
          logRowFlags[LOG_MOTA],   // measured anchor current in Amps
          logRowFlags[LOG_WHEELVEL], // motor axle in rad/s
          logRowFlags[LOG_TURNRATE], // motor axle in rad/s
           logRowFlags[LOG_ENC],    // raw encoder counter
          logRowFlags[LOG_POSE],   // calculated pose x,y,th
          logRowFlags[LOG_BATT],  // battery oltage in Volts
           logRowFlags[LOG_BAL_CTRL], // ballance controller info
           logRowFlags[LOG_EXTRA],   // not implemented
           logInterval,
           logRowFlags[LOG_CTRLTIME],   // time spend on control
           logRowCnt, logRowsCntMax      
  );  
  usb_send_str(reply);
}

void sendStatusVersion()
{
  const int MRL = 100;
  char reply[MRL];
  const char * p1 = REV;
  snprintf(reply, MRL, "version %d.%ld.%d\n", REV_MAIN,  strtol(&p1[5], NULL, 10), REV_MINOR);
  usb_send_str(reply);
}


// parse a user command and execute it, or print an error message
//
void parse_and_execute_command(const char *buf, uint8_t num)
{ // first character is the port letter
  const int MSL = 100;
  char s[MSL];
  //
  if (buf[1] == '=')
  { // one character assignment command
    switch (buf[0])
    {
      case 'i':  localEcho = buf[2] == '1';      break;
      case 'M':
        if (missionState == 0)
        { // mission can not be changed while another mission is running
          mission = strtol(&buf[2], NULL, 10); 
          if (mission >= missionMax)
            mission = missionMax - 1;
        }
        else
          usb_send_str("#* sorry, a mission is in progress.\n");
        break;
      case 's':  logInterval = strtol(&buf[2], NULL, 10); break;
      case 'S':  pushInterval = strtol(&buf[2], NULL, 10); break;
      case 'R':  sendStatusWhileRunning = strtol(&buf[2], NULL, 10); break;
      case 'n':  pushCnt = strtol(&buf[2], NULL, 10); break;
      case 'm':  magCntMax = strtol(&buf[2], NULL, 10); break;
      case 'a':  accCntMax = strtol(&buf[2], NULL, 10); break;
      case 'c':  currentCntMax = strtol(&buf[2], NULL, 10); break;
      default: 
        usb_send_str("#** unknown command!\n");
        break;
    }
  }
  else if (setRegulator(buf))
  { // regulator parameters
  }
  else if (buf[0] == '<')
  { // mission line
    if (strncmp(&buf[1], "clear", 5) == 0)
      mLinesCnt = 0;
    else if (strncmp(&buf[1], "add", 3) == 0)
    {
      if (mLinesCnt < mLinesCntMax)
      {
        mLines[mLinesCnt].decodeLine(&buf[4]);
        if (mLines[mLinesCnt].valid)
          mLinesCnt++;
        else
        {
          const int MRL = 50;
          char reply[MRL];
          snprintf(reply, MRL, "\r\n# add line %d failed: %s\r\n", mLinesCnt + 1, missionErrStr);
          usb_write(reply);
        }
      }
    }
    else if (strncmp(&buf[1], "get", 3) == 0)
    {
      const int MRL = 100;
      char reply[MRL];
      for (int i = 0; i < mLinesCnt; i++)
      {
        //usb_write("# line\n");
        mLines[i].toString(reply, MRL);
        usb_write(reply);
      }
      usb_write("<done>\n");
    }
    else
      usb_write("# no such user mission command\n");
  }
  else if (buf[0] == 'u')
  { // reply on user data request
    switch (buf[1])
    {
      case '0': sendStatusVersion(); break;
      case '1': 
        sendStatusSensor();  break;
      case '2': 
        sendStatusMission(); break;
      case '3': sendStatusLogging();  break;
      case '4': sendStatusRobotID(); break;
      case '5': sendStatusControl(); break;
      case '6': sendStatusMag(); break;
      case '7': sendStatusLS(); break;
      case '8': sendStatusCurrentVolt(); break;
      default:
        usb_send_str("#** unknown status request!\n");
        break;
    }
  }
  else if (buf[0] == 'h' || buf[0] == 'H')
  {
    const int MRL = 200;
    char reply[MRL];
    snprintf(reply, MRL, "# RegBot USB interface " REV_ID " (usb not idle cnt %d)\r\n", usb_not_idle_cnt);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   M=N    Select mission 0=motor test, 1=turn test, 2=Balance, 3=user (M=%d)\r\n", mission);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   i=1    Interactive - use local echo of all commands (i=%d)\r\n", localEcho);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   s=N    log interval in milliseconds (s=%d)\r\n", logInterval);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   n=N    Push in total N status messages (n=%d)\r\n", pushCnt);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   m=N    Measure magnetometer every N ms (m=%d) 0=off\r\n", magCntMax);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   a=N    Measure Accelerometer every N ms (a=%d)\r\n", accCntMax);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   c=N    Measure motor current every N ms  (c=%d)\r\n", currentCntMax);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   log+/-item  Log item (mis %d, acc %d, gyro %d, mag %d, motR %d, "
                               "motV %d, motA %d, enc %d, mvel %d, tr %d, pose %d, bat %d, bcl %d, ct %d)\r\n",
             logRowFlags[LOG_MISSION], logRowFlags[LOG_ACC], logRowFlags[LOG_GYRO], logRowFlags[LOG_MAG],
             logRowFlags[LOG_MOTV_REF], logRowFlags[LOG_MOTV], 
             logRowFlags[LOG_MOTA], logRowFlags[LOG_ENC], logRowFlags[LOG_WHEELVEL], logRowFlags[LOG_TURNRATE], logRowFlags[LOG_POSE], 
             logRowFlags[LOG_BATT], logRowFlags[LOG_BAL_CTRL], logRowFlags[LOG_CTRLTIME]);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   log start   Start logging to %dkB RAM (is=%d, logged %d/%d lines)\r\n", LOG_BUFFER_MAX/1000, loggerLogging(), logRowCnt, logRowsCntMax);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   log get     Transfer log to USB (active=%d)\r\n", logToUSB);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   motw m1 m2   Set motor PWM -1024..1024 (is=%d %d)\r\n", motorAnkerPWM[0], motorAnkerPWM[1]);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   motv m1 m2   Set motor voltage -6.0 .. 6.0 (is=%.2f %.2f)\r\n", motorAnkerVoltage[0], motorAnkerVoltage[1]);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   mote m1 m2   Set motor enable (left right) (is=%d %d)\r\n", motorEnable[0], motorEnable[1]);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   uX           Status: u0:ver,  u1:measurements, u2:mission, u3:log, u4:robot, u5:ctrl, u6:mag, u7:LS, u8:VA\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   rt=d d d d   Regulator turn set: use Kp Ti Td Alpha - see u5\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   rv=d d d d d d d d d Regulator velocity set: use, Kp, Ti, Td, Alpha, stepTime from, to, acc_limit, estimate vel - see u5\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   rid=d d d d d d d  Robot ID set: ID wheelBase gear PPR RadLeft RadRight balanceOffset\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   eew          Save configuration to EE-Prom\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   eer          Read configuration from EE-Prom\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   S=N          Push status every N milliseconds (is %d)\r\n", pushInterval);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   R=N          Push status while running 1=true (is %d)\r\n", sendStatusWhileRunning);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   posec        Reset pose and position\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   mem          Some memory usage info\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   start   start mission (and logging) now\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   stop   terminate mission now\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   <add user-mission-line>  add a user mission line (%d lines loaded)\r\n", mLinesCnt);
    usb_send_str(reply);
    snprintf(reply, MRL, "#   <clear>                  clear all user mission lines\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   <get>                    get all user mission lines\r\n");
    usb_send_str(reply);
    snprintf(reply, MRL, "#   help   This help text\r\n");
    usb_send_str(reply);
  }
  else if (strncmp(buf, "eew", 3) == 0)
    eePromSaveStatus();
  else if (strncmp(buf, "eer", 3) == 0)
    eePromLoadStatus();
  else if (strncmp(buf, "stop", 4) == 0)
    missionStop = true;
  else if (strncmp(buf, "start", 5) == 0)
    missionStart = true;
  else if (strncmp(buf, "posec", 5) == 0)
    clearPose();
  else if (strncmp(buf, "log", 3) == 0)
  { // add or remove
    if (strstr(&buf[3], "start") != NULL)
    { // if not mission timing, then zero here
      if (missionState == 0)
        time = 0.0;
      startLogging(0);
    }
    if (strstr(&buf[3], "stop") != NULL)
    { // 
      stopLogging();
    }
    //     else if (strcasestr(&buf[3], "tosd") != NULL)
//     {
//       logToSD = true;
//       isOK = true;
//     }
    else if (strcasestr(&buf[3], "get") != NULL)
    {
      logToUSB = true;
      if (logRowCnt == 0)
        usb_send_str("% log is empty\n");
    }
    else
    {
      int plus = buf[3] == '+';
      if (strncasecmp(&buf[4], "mis", 3) == 0)
        logRowFlags[LOG_MISSION] = plus;
      else if (strncasecmp(&buf[4], "acc", 3) == 0)
	logRowFlags[LOG_ACC] = plus;
      else if (strncasecmp(&buf[4], "gyro", 4) == 0)
	logRowFlags[LOG_GYRO] = plus;
      else if (strncasecmp(&buf[4], "mag", 3) == 0)
	logRowFlags[LOG_MAG] = plus;
      else if (strncasecmp(&buf[4], "motV", 4) == 0)
	logRowFlags[LOG_MOTV] = plus;
      else if (strncasecmp(&buf[4], "motR", 4) == 0)
        logRowFlags[LOG_MOTV_REF] = plus;
      else if (strncasecmp(&buf[4], "motA", 4) == 0)
	logRowFlags[LOG_MOTA] = plus;
      else if (strncasecmp(&buf[4], "enc", 3) == 0)
	logRowFlags[LOG_ENC] = plus;
      else if (strncasecmp(&buf[4], "mvel", 4) == 0)
        logRowFlags[LOG_WHEELVEL] = plus;
      else if (strncasecmp(&buf[4], "tr", 2) == 0)
        logRowFlags[LOG_TURNRATE] = plus;
      else if (strncasecmp(&buf[4], "pose", 4) == 0)
	logRowFlags[LOG_POSE] = plus;
      else if (strncasecmp(&buf[4], "bat", 3) == 0)
	logRowFlags[LOG_BATT] = plus;
      else if (strncasecmp(&buf[4], "ct", 2) == 0)
        logRowFlags[LOG_CTRLTIME] = plus;
//       else if (strncasecmp(&buf[4], "baro", 4) == 0)
//         logRowFlags[LOG_BARO] = plus;
      else if (strncasecmp(&buf[4], "bcl", 3) == 0)
        logRowFlags[LOG_BAL_CTRL] = plus;
      else if (strncasecmp(&buf[4], "extra", 5) == 0)
        logRowFlags[LOG_EXTRA] = plus;
      //
      initLogStructure(100000 / CONTROL_PERIOD_10us);

    }
  } 
  else if (strncmp(buf, "mote", 4) == 0)
  { // motor enable
    uint8_t m1, m2;
    const char * p1 = &buf[4];
    // get two values - if no value, then 0 is returned
    m1 = strtol(p1, (char**)&p1, 10);
    m2 = strtol(p1, (char**)&p1, 10);
    motorSetEnable(m1, m2);
  }
  else if (strncmp(buf, "motw", 4) == 0)
  {
    int m1, m2;
    const char * p1 = &buf[4];
    // get two values - if no value, then 0 is returned
    m1 = strtol(p1, (char**)&p1, 10);
    m2 = strtol(p1, (char**)&p1, 10);
    motorSetAnkerPWM(m1, m2);
  }
  else if (strncmp(buf, "motv", 4) == 0)
  {
    float m1, m2;
    const char * p1 = &buf[4];
    // get two values - if no value, then 0 is returned
    m1 = strtof(p1, (char**)&p1);
    m2 = strtof(p1, (char**)&p1);
    // limit to 6.0 volt
    if (m1 > 6) 
      m1 = 6.0;
    else if (m1 < -6)
      m1 = -6;
    if (m2 > 6) 
      m2 = 6.0;
    else if (m2 < -6)
      m2 = -6;
    motorAnkerVoltage[0] = m1;
    motorAnkerVoltage[1] = m2;
    //addMotorVoltage(m1, m2);
    // transfer to PWM
    motorSetAnchorVoltage();
  }
  else if (strncmp(buf, "rid", 3) == 0)
  { // robot ID and other permanent stuff
    setRobotID(&buf[4]);
  }
  else if (strncmp(buf, "gyroo", 5) == 0)
  {
    gyroOffsetDone = false;
  }
  else if (strncmp(buf,"mem", 3) == 0)
  { // memory usage
    snprintf(s, MSL, "# Main 3 areana=%d (m1=%x &time=%x s=%x)\n", mallinfo().arena, 
             (unsigned int)m1, (unsigned int)&time, (unsigned int)s);
    usb_send_str(s);      
    snprintf(s, MSL, "# Main log buffer from %x to %x\n", (unsigned int)logBuffer, (unsigned int)&logBuffer[LOG_BUFFER_MAX-1]);
    usb_send_str(s);      
  }
  else
  {
    usb_send_str("#** Unknown '");
    usb_serial_putchar(buf[0]);
    usb_send_str("' command (may try: stty -echo --file=/dev/ttyACM0)\r\n");
    usb_serial_flush_input();
  }
}

/////////////////////////////////////////////////////


//////////////////////////////////////////

void stateToLog()
{ 
//   const int MSL = 100;
//   char s[MSL];
// //  snprintf(s, MSL, "# state to log, flags, time=%d, mission=%d,...\n", logRowFlags[LOG_TIME], logRowFlags[LOG_MISSION]);
//   snprintf(s, MSL, "#time %.3f mission %d, state %d.%d, logger line %d/%d\r\n", 
//            time, mission, missionState, misLineNum, logRowCnt, logRowsCntMax);
//   usb_send_str(s);
  if (addNewRowToLog())
  {
    addToLog(LOG_TIME, &time, sizeof(time));
    if (logRowFlags[LOG_MISSION])
    {
      if (mission == 3)
        // log line number not state
        addToLog(LOG_MISSION, &misLineNum, sizeof(missionState));
      else
        addToLog(LOG_MISSION, &missionState, sizeof(missionState));
    }
    if (logRowFlags[LOG_ACC])
      addToLog(LOG_ACC, imuAcc, sizeof(imuAcc));
    if (logRowFlags[LOG_GYRO])
      addToLog(LOG_GYRO, imuGyro, sizeof(imuGyro));
    if (logRowFlags[LOG_MAG])
      addToLog(LOG_MAG, imuMag, sizeof(imuMag));
    if (logRowFlags[LOG_MOTV_REF])
      addToLog(LOG_MOTV_REF, regul_vel_tot_ref, sizeof(regul_vel_tot_ref));
    if (logRowFlags[LOG_MOTV])
    {
      int16_t mv[2];
      mv[0] = int(motorAnkerVoltage[0] * 1000);
      mv[1] = int(motorAnkerVoltage[1] * 1000);
      addToLog(LOG_MOTV, mv, sizeof(mv));
    }
    if (logRowFlags[LOG_ENC])
      addToLog(LOG_ENC, encoder, sizeof(encoder));
    if (logRowFlags[LOG_MOTA])
    { // need to sort out sign first
      int16_t mc[2];
//      int16_t mc[4];
//       if (directionFWD[0])
//         mc[0] = motorCurrent[0];
//       else
//         mc[0] = -motorCurrent[0];
//       if (directionFWD[1])
//         mc[1] = motorCurrent[1];
//       else
//         mc[1] = -motorCurrent[1];
      mc[0] = motorCurrentM[0];
      mc[1] = motorCurrentM[1];
      // save signed current
      addToLog(LOG_MOTA, mc, sizeof(mc));
    }
    if (logRowFlags[LOG_WHEELVEL])
      addToLog(LOG_WHEELVEL, wheelVelocityEst, sizeof(wheelVelocityEst));
    if (logRowFlags[LOG_TURNRATE])
      addToLog(LOG_TURNRATE, &turnRate, sizeof(turnRate)); 
    if (logRowFlags[LOG_POSE])
      addToLog(LOG_POSE, pose, sizeof(pose));
    if (logRowFlags[LOG_BATT])
      addToLog(LOG_BATT, &batVoltInt, sizeof(batVoltInt));
    if (logRowFlags[LOG_CTRLTIME])
      addToLog(LOG_CTRLTIME, &controlUsedTime, sizeof(controlUsedTime));
//     if (logRowFlags[LOG_BARO])
//     { // pack to 16 bit
//       int16_t bv[4];
//       uint32_t * bp = (uint32_t*) &bv[1];
//       bv[0] = (uint16_t)baro180data.tempC;
//       *bp   = baro180data.presPascal;
//       bv[3] = baro180data.height * 100;
//       addToLog(LOG_BARO, &bv, sizeof(bv));
//     }
    if (logRowFlags[LOG_BAL_CTRL])
    {
      float v[5] = {balTiltRef, regBalVelUI[0], regBalVelE[0], regBalVelUD[0], regBalE[0]};
      addToLog(LOG_BAL_CTRL, &v, sizeof(v)); 
    }
    //     if (logRowFlags[LOG_EXTRA])
//     {
//       float val[4] = {regTurnE[0], regTurnU[0], regul_turn_vel_reduc[0], regul_turn_vel_reduc[1]};
//       addToLog(LOG_EXTRA, val, sizeof(val));
//     }
    if (logRowFlags[LOG_EXTRA])
    {
      //float val[4] = {regBalE[0], regBalU[0], regBalVelE[0], regBalVelU[0]};
      //float val[4] = {tiltu1, 0, accAng, gyroTilt};
      // extra as values in velocity controller - left motor
      float val[4] = {regVelELeft[0], regVelUDLeft[0], regul_vel_tot_ref[0], regVelULeft[0]};
      addToLog(LOG_EXTRA, val, sizeof(val));
    }
  }
  else
    stopLogging();
}

///////////////////////////////////

void stateToUsb()
{ // read start switch
  int switch2 = digitalRead(11);
  if ((pushCnt > 0) and (logInterval > 0))
  {
    const int MRL = 300;
    char reply[MRL];
    float mc0;
    float mc1;
//     if (useADCInterrupt)
//     {
//       mc0 = float(motorCurrent[0]) * 1.2 / useADCMaxADCValue / 0.525;
//       mc1 = float(motorCurrent[1]) * 1.2 / useADCMaxADCValue / 0.525;
//     }
//     else
//     {
//       mc0 = float(motorCurrent[0]) * 1.2 / useADCMaxADCValue / 0.525;
//       mc1 = float(motorCurrent[1]) * 1.2 / useADCMaxADCValue / 0.525;
//     }
    if (directionFWD[0])
      mc0 = -mc0;
    if (directionFWD[1])
      mc1 = -mc1;    
    snprintf(reply, MRL, "hb %lu a:%6.1f%6.1f%6.1f g:%6.1f%6.1f%6.1f c %5.3f %5.3f %5d %5d e %3lx %3lx v %5.3f %5.3f pose %6.3f %6.3f %5.1f sw %d bat %.2f\r\n",
//                         " baro %.1f %d %d\r\n",
            hbTimerCnt,
             imuAcc[0] * accScaleFac, imuAcc[1] * accScaleFac, imuAcc[2] * accScaleFac,
             imuGyro[0] * gyroScaleFac, imuGyro[1] * gyroScaleFac, imuGyro[2] * gyroScaleFac,
//            imuMag[0], imuMag[1], imuMag[2],
            motorCurrentA[0], motorCurrentA[1], motorCurrentM[0], motorCurrentM[1],
            encoder[0] & 0xfff, encoder[1] & 0xfff, wheelVelocity[0], wheelVelocity[1],
            pose[0], pose[1], pose[2] * 180 / M_PI,
            switch2, batVoltFloat
//              baro180data.tempC / 10.0, baro180data.presPascal, baro180data.measCnt
            );
    usb_send_str(reply);
    pushCnt--;
  }
}

/////////////////////////////////////////

// void logSendToSD()
// {
//   logToSD = true;
// }

//////////////////////////////////////////

int getUInt16FromBuffer()
{
  uint8_t h = Wire.read();
  uint8_t l = Wire.read();
  int a = (h << 8) + l;
  return a;
}

////////////////////////////////////////////

int getInt16FromBuffer()
{ // get signed int from 2 bytes
  int8_t h = Wire.read();
  int8_t l = Wire.read();
  int a = ((int)h << 8) | (int)l;
  return a;
}

/////////////////////////////////////////////


////////////////////////////////////////////////

void eePromPush(uint32_t value)
{
//   const int MSL = 100;
//   char s[MSL];
//   snprintf(s, MSL, "# ee saved: at %lu, value %lu\r\n", eePushAdr, value);
//   usb_send_str(s);
  //
  eeprom_busy_wait();
  eeprom_write_dword((uint32_t*)eePushAdr, value);
  eePushAdr += 4;
}

//////////////////////////////////////////////

uint32_t eePromRead()
{
//   const int MSL = 100;
//   char s[MSL];
  //
  uint32_t b = eeprom_read_dword((uint32_t*)eePushAdr);
  // debug
//   snprintf(s, MSL, "# ee loaded: at %lu, value %lu\r\n", eePushAdr, b);
//   usb_send_str(s);
  // debug end
  eePushAdr += 4;

  return b;
}

//////////////////////////////////////////////////

void eePromSaveStatus()
{ // reserve first 4 bytes for dword count
  eePushAdr = 4;
  eeprom_initialize();
  eePromPush(getRevisionNumber());
  // main values
  //int accCnt = 0, accCntMax = 1;
  // read motor feedback current every this currentCntMax
  //int currentCnt = 1, currentCntMax = 1;
  eePromPush(accCntMax);
  eePromPush(currentCntMax);
  // save robot config
  eePromSaveRobotId();
  // save gyro zero offset
  eePromSaveGyroZero();
  // logger values
  eePromSaveStatusLog();
  // save controller status
  // values to controller
  eePromSaveCtrl();
  // then save length
  const int MSL = 100;
  char s[MSL]; 
  uint32_t cnt = eePushAdr;
  eePushAdr = 0;
  if (robotId <= 0)
  {
    // ignore ee-prom at next reboot
    eePromPush(0);
    snprintf(s, MSL, "# EE-prom D set to default values at next reboot\r\n");
  }
  else
  {
    eePromPush(cnt);
    snprintf(s, MSL, "# Saved %lu values (%lu/2048 bytes) to EE-prom D\r\n", cnt, cnt*4);
  }
  // tell user
  usb_send_str(s);
}

//////////////////////////////////////////////////

void eePromLoadStatus()
{ 
  eePushAdr = 0;
  uint32_t cnt = eePromRead();
  uint32_t rev = eePromRead();
  if (cnt == 0 or cnt >= 512 or rev == 0)
  {
    const int MSL = 100;
    char s[MSL]; 
    snprintf(s, MSL, "# No saved configuration - save a configuration first (cnt=%lu, rev=%lu)\r\n", cnt, rev);
    usb_send_str(s);
    return;
  }
  if (rev != getRevisionNumber())
  {
    const int MSL = 100;
    char s[MSL];
    snprintf(s, MSL, "# configuration from old SW version now:%f != ee:%f\r\n", getRevisionNumber()/100.0, rev/100.0);
    usb_send_str(s);
  }
  // main values
  accCntMax = eePromRead();
  currentCntMax = eePromRead();
  // robot specific settings
  eePromLoadRobotId();
  // gyro zero value
  eePromLoadGyroZero();
  // values to logger
  eePromLoadStatusLog();
  // values to controller
  eePromLoadCtrl();
  //saveStatusToEEPromMission();
  if (cnt != eePushAdr)
  {
    const int MSL = 100;
    char s[MSL];
    snprintf(s, MSL, "# configuration size has changed! %lu != %lu\r\n", cnt, eePushAdr);
    usb_send_str(s);
  }
}
